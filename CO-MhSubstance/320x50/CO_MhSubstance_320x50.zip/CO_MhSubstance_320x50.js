(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"CO_MhSubstance_320x50_atlas_P_1", frames: [[0,0,232,87]]},
		{name:"CO_MhSubstance_320x50_atlas_NP_1", frames: [[0,0,1456,180]]}
];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Buttonshad = function() {
	this.initialize(ss["CO_MhSubstance_320x50_atlas_P_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.MhSubstance_728x90 = function() {
	this.initialize(ss["CO_MhSubstance_320x50_atlas_NP_1"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.HS_logowhite = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Ap9EXIAHnRINagKIgCh7IGDgCIAZKDgAFdgfQgVAOgIAYQgGAUAAAZQAAAaAGATQAJAZAVAOQAVAOAgAAQAyAAAeggQADgDgEgCIgZgYQgCgDgEADQgSARgZAAQgfAAgHgZIgDgKQAAgBAAgBQABAAAAAAQAAgBABAAQAAAAABAAIBxAAQAEAAAAgEQAAglgGgUQgIgYgVgOQgVgOgfABQgeAAgVANgAgnAvQgVAQAAAdQAAAdASAPQARAOAaAAQAjAAAQgVIABAAIAAANQAAADAEAAIArAAQADAAAAgDIAAh4QAAgjgSgPQgUgRgtABQgqAAgaASQgDACACADIARAeQACADADgDQAQgKAZAAQAWAAAIAEQAIAHAAANIAAAHQAAABAAAAQAAABAAAAQgBAAAAAAQgBABAAAAIghAAQgkAAgUAOgAnMBXIgZAdQgCACACADQAiAdAzAAQAoAAAWgSQAVgRABgeQAAgyg/gGIgUgCQgPgCgGgEQgFgDAAgHQAAgOAYgBQAbAAAXAOQAEADACgDIAVgaQADgDgDgDQgegWguAAQgkgBgVARQgUAQAAAaQAAAzA9AHIAVABQAQACAGAEQAFAEAAAHQAAASgdAAQgfAAgagVIgDgBIgDABgACfgkIAACyQAAADAEAAIAuAAQAEAAAAgDIAAhjQAAgnAdgCQAMAAAPAJQADABACgCIAWgmQACgEgDgCQgNgLgUABQgjgBgOAYIAAAAIAAgPQAAgFgEAAIguAAQgEAAAAAFgAieAiIAABsQAAADAEAAIAuAAQAEAAAAgDIAAh2QAAgegRgTQgRgUgeABQghAAgPAUIgBAAIAAhZQAAgDgEAAIguAAQgEAAAAADIAAD/QAAADAEAAIAuAAQAEAAAAgDIAAhsQAAgPAIgKQAIgJAOAAQAdAAAAAig");
	this.shape.setTransform(25.025,83.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgeABQAAgVAgAAIAaAAQABABABAAQAAAAAAAAQABAAAAABQAAAAAAABIAAANQAAAZgiAAQgbgBAAgTg");
	this.shape_1.setTransform(27.15,92.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgeATQAAAAgBgBQAAAAgBAAQAAAAAAgBQAAAAAAgBQAAgGACgIQAHgTAXgBQAZABAGATQACAGAAAIQAAABAAAAQAAABAAAAQgBAAAAAAQAAABgBAAg");
	this.shape_2.setTransform(65.075,85.05);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AqIk4IUcAvIAII0I03AOgAhWAjQgVAQAAAeQgBAdAUAPQAQAOAbAAQAkAAAPgVIAAANQAAADAEAAIArAAQAEAAAAgDIAAh5QAAgjgSgPQgUgRgsAAQgrAAgcATQgCACACADIARAfQACACADgBQARgMAZAAQAWAAAIAGQAHAGAAAMIAAAHQAAABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIghAAQgjAAgVAOgAkagrQgVAOgIAZQgHATAAAZQAAAXAHAWQAIAaAWAOQAVAOAgAAQAzAAAdggQADgDgDgCIgagYQgCgDgDADQgSAQgZAAQgfAAgIgYQgCgDgBgIQAAAAABgBQAAAAAAgBQAAAAABAAQAAAAABAAIBxAAQAFAAAAgEQAAgmgGgTQgJgZgUgOQgWgOgfAAQgeAAgVAOgADcgxIAAAhQAAAEAFAAIALAAQABAAAAAAQABAAAAAAQAAAAAAABQAAAAAAABIAABUQAAAhAOAPQAOAPAgAAIAUAAQAEAAABgEIAAgnQgBgDgEAAIgJAAQgJAAgDgEQgFgFAAgKIAAhSQAAgBABAAQAAgBAAAAQAAAAABAAQAAAAAAAAIAYAAQAEAAABgEIAAghQgBgDgEAAIgYAAQAAAAAAAAQgBgBAAAAQAAAAAAgBQgBAAAAgBIAAgyQAAgEgDAAIguAAQgFAAAAAEIAAAyQAAABAAAAQAAABAAAAQAAAAgBABQAAAAgBAAIgLAAQgFAAAAADgABth9IAADKQAAAfANAPQAOAOAfAAIAVAAQADAAAAgEIAAgnQAAgDgDAAIgIAAQgRAAAAgSIAAjGQAAgEgEAAIgvAAQgDAAAAAEgAHggBQAIAIAAAQIAABsQAAADADAAIAvAAQAEAAAAgDIAAh3QAAgegRgTQgQgUgfAAQghAAgQAWIAAAAIAAhaQAAgEgEAAIguAAQgFAAAAAEIAAEAQAAADAFAAIAuAAQAEAAAAgDIAAhsQAAgQAIgIQAIgKAOAAQAOAAAHAKgAmpgBQAHAIAAAQIAABsQAAADAFAAIAuAAQAEAAAAgDIAAh3QAAgegRgTQgRgUgfAAQghAAgPAWIAAhaQAAgEgEAAIgvAAQgDAAAAAEIAAEAQAAADADAAIAvAAQAEAAAAgDIAAhsQAAgQAIgIQAHgKAOAAQAOAAAIAKg");
	this.shape_3.setTransform(-21.95,31.325);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgeABQAAgVAgAAIAbAAQAAAAABABQAAAAAAAAQABAAAAABQAAAAAAABIAAANQAAAZgiAAQgbgBAAgTg");
	this.shape_4.setTransform(-24.5,39.05);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgeASQgBAAAAAAQgBAAAAAAQAAAAAAgBQgBAAAAgBQAAgGADgIQAHgUAXAAQAYAAAIAUQACAIAAAGQAAABgBAAQAAABAAAAQAAAAgBAAQAAAAgBAAg");
	this.shape_5.setTransform(-45.05,31.55);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AJdAwIAcgBQABAJANAAQAPABAAgNIAAgIQgIAFgMAAQgRAAgLgMQgKgLAAgSQAAgSAKgLQALgMARAAQANAAAIAHIAAgFIAaAAIAABRQAAARgLALQgLAKgTAAQgmAAgFgggAJ4AAQAAASAPAAQAHgBAEgEQAEgEAAgIIAAgCQAAgHgEgFQgFgEgGAAQgPAAAAARgALLAdQgMgLAAgSQAAgSAMgLQAMgMATAAQATAAAMAMQAMALAAASQAAASgMALQgMAMgTAAQgTAAgMgMgALbAAQAAASAPAAQAPAAAAgSQAAgRgPAAQgPAAAAARgAILAeQgLgLAAgTQAAgSALgLQAMgMASAAQASAAAKAKQALALAAATIAAAIIgzAAQAAANAMAAQAIAAACgHIAcACQgCAMgKAHQgLAHgOAAQgTAAgMgLgAI0gIQgBgMgKAAQgLAAgBAMIAXAAIAAAAgAFOAZQgRgQAAgaQAAgaARgRQAQgQAbAAQAbAAARAQQARARAAAaQAAAagRAQQgRAQgbAAQgbAAgQgQgAFjgpQgIAJAAAPQAAAPAIAJQAIAIAOAAQAOAAAIgIQAJgJAAgPQAAgPgJgJQgIgIgOgBQgOABgIAIgACHAdQgMgLAAgSQAAgSAMgLQAMgMATAAQATAAAMAMQAMALAAASQAAASgMALQgMAMgTAAQgTAAgMgMgACXAAQAAASAPAAQAPAAAAgSQAAgRgPAAQgPAAAAARgAAJAeQgLgLAAgTQAAgSALgLQALgMATAAQARAAALAKQALALAAATIAAAIIgzAAQAAANAMAAQAIAAACgHIAcACQgCAMgLAHQgKAHgPAAQgTAAgLgLgAAygIQgBgMgLAAQgKAAgBAMIAXAAIAAAAgAiVASQAAgWAigCIAJAAIAAgEQAAgIgGAAQgHAAAAAHIgcgBQAAgLAJgJQAKgJAQAAQAiAAAAAhIAAAvIgaAAIAAgFQgHAHgMAAQgaAAAAgXgAh6AQQAAAFAHAAQAEAAACgCQADgDAAgDIAAgEIgHAAQgJABAAAGgAlOAfQgNgKAAgTIAegBQAAAGAFAEQAFAFAHAAQANgBAAgIQAAgHgTgFQgTgFgIgGQgLgHAAgQQAAgQAKgJQALgMAUAAQAUAAAMALQAMAJABASIgeABQAAgNgOAAQgMAAAAAKQAAAEAEACQADADAMADQATAEAIAHQALAJAAANQAAASgMAKQgMAIgTAAQgVAAgNgKgAoUANIAAgdIgOAAIAAgXIAOAAIABgZIAbAAIAAAZIARAAIAAAXIgRAAIAAAWQAAALALAAIAGgBIAAAYIgNABQggAAAAgcgAqjASQAAgWAigCIAKAAIAAgEQAAgIgHAAQgHAAAAAHIgcgBQAAgLAJgJQAKgJAQAAQAiAAAAAhIAAAvIgaAAIAAgFQgHAHgMAAQgaAAAAgXgAqIAQQAAAFAHAAQAEAAACgCQADgDAAgDIAAgEIgHAAQgJABAAAGgAr0AeQgLgLAAgTQAAgSALgLQALgMATAAQARAAALAKQALALAAATIAAAIIgzAAQAAANAMAAQAIAAACgHIAcACQgCAMgLAHQgKAHgOAAQgTAAgMgLgArLgIQgBgMgKAAQgLAAgBAMIAXAAIAAAAgANWAnIAAgpQAAgNgKAAQgLAAAAANIAAApIgcAAIAAhOIAaAAIAAAFQAGgHAOAAQAOAAAIAIQAJAJAAAPIAAAwgAHGAnIAAhOIAbAAIAAAGQAHgHAOAAIAAAbQgJAAgGAFQgFAEAAAGIAAAlgADlAnIAAg3IgOAAIAAgXIAOAAIAAgFQAAgQAKgKQAKgJAQAAIAJAAIAAAZIgGgBQgFAAgDADQgDADAAAEIAAAGIARAAIAAAXIgRAAIAAA3gAg7AnIAAhOIAbAAIAAAGQAGgHAPAAIAAAbQgKAAgFAFQgFAEAAAGIAAAlgAjAAnIAAgpQAAgNgKAAQgLAAAAANIAAApIgcAAIAAh1IAcAAIAAArQAGgGAMAAQAOAAAIAIQAJAJAAAPIAAAwgAmnAnIAAgpQAAgNgKAAQgLAAAAANIAAApIgcAAIAAh1IAcAAIAAArQAHgGALAAQAOAAAIAIQAJAJAAAPIAAAwgApJAnIAAh1IAcAAIAAB1gAstAnIAAgsIgmAAIAAAsIgeAAIAAhwIAeAAIAAAqIAmAAIAAgqIAeAAIAABwg");
	this.shape_6.setTransform(0.175,134.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HS_logowhite, new cjs.Rectangle(-88.7,0,177.5,143), null);


(lib.HEAD3type = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgEgFAAgHQAAgGAEgFQAFgFAHAAQAIAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgIAAQgHAAgFgFg");
	this.shape.setTransform(32.125,39.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AghAiQgMgNABgVQAAgUAMgNQANgNAUABQAWAAALAMQALANAAAVIAAAFIg7AAQAAAXAWAAQAPAAAGgPIAQAJQgLAXgfAAQgXAAgNgMgAARgHQgBgMgEgGQgDgEgIAAQgPgBgBAXIAgAAIAAAAg");
	this.shape_1.setTransform(25.15,36.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgrBAQgLgEABgIQAAgNAVgEQgSgFAAgOQAAgNARgFQgNgHAAgRQAAgNAMgKQAMgIAUAAQAOAAALAGQAEgRAOAAQAGAAAEAEQADADAAAFQAAAGgCADQgEADgEAAQgIAAgCgGIgEAEQAJAJAAALQAAAPgMAHQgLAHgUAAQgLAAgJgCQgEABAAAEQAAAGAKgBIAmAAQAdAAAAAaQAAAgg1AAQgbAAgMgFgAgfAxQAAAEAGACQAHACAPAAQAeAAABgLQgBgFgCgCQgEgBgJAAIggAAQgLADAAAIgAgRgbIAAADQAAAPANAAQANAAAAgPIAAgDQAAgQgMAAQgOAAAAAQg");
	this.shape_2.setTransform(15.25,37.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoAoQgHgGAAgLQAAgQARgHQALgFAcgFIAAgFQAAgOgPAAIgJABQACADAAAFQAAAGgFAEQgEADgGAAQgRAAAAgOQAAgZAsABQAVgBAJAIQAKAGAAARIAAAmQAAAFADAAIAGAAIAAAQIggAAQgEgFgDgJQgDAHgIAFQgIAEgKAAQgNABgHgHgAgLAHQgIAEAAAHQAAALALAAQAIAAAEgGQAFgGAAgJIAAgHQgOADgGADg");
	this.shape_3.setTransform(4.875,36.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_4.setTransform(-4.675,36.025);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AggAiQgNgNAAgVQAAgUANgNQANgNAUABQAWAAALAMQAMANAAAVIAAAFIg8AAQABAXAUAAQAQAAAHgPIAOAJQgKAXgfAAQgWAAgNgMgAAQgHQAAgMgDgGQgEgEgHAAQgQgBAAAXIAeAAIAAAAg");
	this.shape_5.setTransform(-13.95,36.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgKAtIgdhEQgCgEgEAAIgFAAIAAgQIAyAAIAAAQIgGAAQgFAAABAFIAPAmIAQglQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAIgGAAIAAgQIAoAAIAAAQIgFAAQgEAAgCAEIgeBEg");
	this.shape_6.setTransform(-23.95,36.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgiAiQgNgNAAgVQAAgUANgNQANgNAVABQAWgBANANQANANAAAUQAAAVgNANQgNAMgWAAQgVAAgNgMgAgNgWQgEAHAAAPIAAABQAAAPAEAHQAEAHAJgBQAKABAEgHQAEgHAAgPIAAgBQAAgPgEgHQgEgGgKAAQgIAAgFAGg");
	this.shape_7.setTransform(-34.25,36.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgfAiQgNgMAAgWQAAgUANgNQANgMAWAAQATgBALAJQALAHAAAOQAAAKgFAGQgFAEgIAAQgHAAgFgEQgEgDAAgGQAAgMAMgDQgEgFgLAAQgWgBAAAcIAAACQAAAcAVAAQAQAAAGgPIAPAJQgJAYgfAAQgWAAgNgMg");
	this.shape_8.setTransform(-43.975,36.15);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKAzQgGgHgBgPIAAgsIgLAAIAAgOIAGgBQALgCACgKIABgPIAUAAIAAAaIAQAAIAAAQIgRAAIAAAsQAAALAKAAIAIgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_9.setTransform(-56.2,35);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAFAtIAAgQIAGAAQADAAAAgFIAAgiQAAgPgMAAQgPAAAAAYIAAAZQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAAQQAIgQAUAAQAdAAAAAiIAAAiQAAAFADAAIAGAAIAAAQg");
	this.shape_10.setTransform(-64.525,36.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggAiQgMgNgBgVQAAgUANgNQANgNAUABQAWAAALAMQALANAAAVIAAAFIg7AAQAAAXAVAAQAQAAAHgPIAOAJQgKAXgfAAQgXAAgMgMgAAQgHQAAgMgDgGQgEgEgIAAQgOgBgBAXIAeAAIAAAAg");
	this.shape_11.setTransform(-74.9,36.15);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAhAtIAAgQIAEAAQAEAAAAgFIAAggQAAgRgMAAQgOAAAAAWIAAAbQAAAFADAAIAGAAIAAAQIguAAIAAgQIAFAAQADAAAAgFIAAghQAAgQgMAAQgOAAAAAWIAAAbQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAARQAIgRATAAQAUAAAFATQAHgTAWAAQAeAAAAAjIAAAhQAAAFADAAIAGAAIAAAQg");
	this.shape_12.setTransform(-87.825,36.025);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgKAzQgHgHABgPIAAgsIgMAAIAAgOIAGgBQALgCABgKIADgPIATAAIAAAaIAQAAIAAAQIgRAAIAAAsQAAALAKAAIAIgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_13.setTransform(-99.35,35);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgoAoQgHgGAAgLQAAgQARgHQALgFAcgFIAAgFQAAgOgPAAIgJABQACADAAAFQAAAGgFAEQgEADgGAAQgRAAAAgOQAAgZAsABQAVgBAJAIQAKAGAAARIAAAmQAAAFADAAIAGAAIAAAQIggAAQgEgFgDgJQgDAHgIAFQgIAEgKAAQgNABgHgHgAgLAHQgIAEAAAHQAAALALAAQAIAAAEgGQAFgGAAgJIAAgHQgOADgGADg");
	this.shape_14.setTransform(-107.175,36.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AghAiQgMgNABgVQAAgUAMgNQANgNAUABQAWAAALAMQAMANAAAVIAAAFIg8AAQABAXAVAAQAPAAAGgPIAQAJQgLAXgfAAQgXAAgNgMgAARgHQgBgMgEgGQgDgEgIAAQgOgBgCAXIAgAAIAAAAg");
	this.shape_15.setTransform(-117.15,36.15);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_16.setTransform(-126.375,36.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKAzQgHgHABgPIAAgsIgMAAIAAgOIAGgBQALgCABgKIADgPIATAAIAAAaIAQAAIAAAQIgRAAIAAAsQAAALALAAIAHgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_17.setTransform(-134.1,35);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AggAhQgNgMAAgVQAAgUANgMQANgOAUAAQAWAAALANQAMAMgBAXIAAADIg7AAQABAYAUAAQAQAAAHgPIAOAJQgKAXgfABQgXAAgMgOgAAQgHQAAgMgDgFQgEgGgHAAQgQAAAAAXIAeAAIAAAAg");
	this.shape_18.setTransform(108.8,15.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQABgFgGgDQgDgBgKgCQgOgDgGgFQgKgFAAgNQAAgOAKgJQALgHARgBQAUABAOAGIAAAYIgUAAIAAgOQgFgCgHAAQgNAAAAAKQgBAFAGACQACABALACQAOADAGAFQALAGgBANQABAOgLAIQgLAJgRAAQgTgBgRgGg");
	this.shape_19.setTransform(99.85,15.3);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_20.setTransform(90.225,15.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AghAhQgLgMAAgVQAAgUAMgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQABAYAVAAQAPAAAHgPIAPAJQgLAXgfABQgWAAgOgOgAARgHQgBgMgEgFQgDgGgHAAQgPAAgBAXIAfAAIAAAAg");
	this.shape_21.setTransform(75.8,15.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgfAiQgNgMAAgWQAAgUANgNQANgNAWAAQATABALAHQALAJAAAOQAAAJgFAFQgFAFgIAAQgHAAgFgEQgEgDAAgGQAAgNAMgBQgEgHgLAAQgWABAAAbIAAADQAAAcAVAAQAQAAAGgQIAPAJQgJAZgfAAQgWAAgNgNg");
	this.shape_22.setTransform(66.325,15.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AAFAtIAAgQIAGAAQADAAAAgFIAAgiQAAgPgMAAQgPAAAAAYIAAAZQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAAQQAIgQAUAAQAdAAAAAiIAAAiQAAAFADAAIAGAAIAAAQg");
	this.shape_23.setTransform(56.125,15.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgoAoQgHgHAAgKQAAgQARgHQALgFAcgFIAAgFQAAgPgPAAIgJABQACAEAAAEQAAAHgFADQgEAFgGAAQgRAAAAgPQAAgZAsAAQAVABAJAGQAKAIAAAQIAAAmQAAAFADAAIAGAAIAAAQIggAAQgEgGgDgIQgDAHgIAEQgIAFgKABQgNAAgHgHgAgLAGQgIAFAAAIQAAAKALAAQAIAAAEgGQAFgFAAgKIAAgHQgOACgGADg");
	this.shape_24.setTransform(45.625,15.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgKAzQgGgHAAgPIAAgsIgMAAIAAgPIAGAAQALgCACgKIACgPIATAAIAAAZIAQAAIAAARIgRAAIAAAsQAAALAKAAIAIgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_25.setTransform(37.2,14.15);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQABgFgGgDQgDgBgKgCQgOgDgGgFQgLgFABgNQAAgOAKgJQALgHARgBQAUABAOAGIAAAYIgUAAIAAgOQgFgCgHAAQgNAAAAAKQgBAFAGACQACABALACQAOADAGAFQAKAGAAANQAAAOgKAIQgLAJgRAAQgSgBgSgGg");
	this.shape_26.setTransform(30.2,15.3);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgRAoIgFAUIgVAAIABgeIAAhDQAAgGgDAAIgHAAIAAgQIASAAQAOAAAHgCIAAAxQAJgSATAAQASAAAKANQALAMAAAVQAAAVgMAMQgKANgSAAQgYAAgHgWgAgNAOIAAADQABAbAQAAQATAAgBgbIAAgDQABgagTABQgQgBgBAag");
	this.shape_27.setTransform(20.45,13.75);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_28.setTransform(9.575,15.425);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQABgFgGgDQgDgBgKgCQgOgDgGgFQgLgFABgNQAAgOAKgJQALgHARgBQAUABAOAGIAAAYIgUAAIAAgOQgFgCgHAAQgNAAAAAKQgBAFAGACQACABALACQAOADAGAFQAKAGAAANQAAAOgKAIQgLAJgRAAQgSgBgSgGg");
	this.shape_29.setTransform(0.05,15.3);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AghAhQgMgMABgVQAAgUAMgMQANgOAUAAQAWAAALANQALAMAAAXIAAADIg7AAQAAAYAWAAQAPAAAGgPIAQAJQgLAXgfABQgXAAgNgOgAARgHQgBgMgEgFQgDgGgIAAQgPAAgBAXIAgAAIAAAAg");
	this.shape_30.setTransform(-13.1,15.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AghAhQgLgMAAgVQAAgUAMgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQABAYAVAAQAPAAAGgPIAQAJQgLAXgfABQgWAAgOgOgAARgHQgBgMgEgFQgDgGgHAAQgPAAgCAXIAgAAIAAAAg");
	this.shape_31.setTransform(-22.75,15.3);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_32.setTransform(-31.975,15.175);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgbA+IAAgRIAHAAQADAAAAgEIAAgyIgLAAIAAgRIALAAIAAgDQAAgSAHgHQAHgHAPAAQAKABAHADIAAAPQgCgBgFAAQgHAAgDAEQgCADAAAKIAQAAIAAARIgPAAIAAAyQAAAEADAAIAIAAIAAARg");
	this.shape_33.setTransform(-39.3,13.55);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AglAoIAAgYIAVAAIAAAPQAGABAIAAQANAAAAgKQABgFgGgDQgDgBgKgCQgNgDgIgFQgKgFABgNQAAgOAKgJQAKgHASgBQATABAPAGIAAAYIgUAAIAAgOQgEgCgIAAQgNAAAAAKQAAAFAFACQACABAKACQAPADAGAFQAKAGAAANQAAAOgKAIQgKAJgTAAQgSgBgSgGg");
	this.shape_34.setTransform(-50.7,15.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_35.setTransform(-59.225,15.175);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AggAhQgNgMAAgVQAAgUANgMQANgOAUAAQAWAAALANQAMAMgBAXIAAADIg7AAQABAYAUAAQAQAAAHgPIAOAJQgKAXgfABQgXAAgMgOgAAQgHQAAgMgDgFQgEgGgHAAQgQAAAAAXIAeAAIAAAAg");
	this.shape_36.setTransform(-68.5,15.3);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AgbA+IAAgRIAHAAQADAAAAgEIAAgyIgLAAIAAgRIALAAIAAgDQAAgSAHgHQAHgHAPAAQAKABAHADIAAAPQgCgBgFAAQgHAAgDAEQgCADAAAKIAQAAIAAARIgPAAIAAAyQAAAEADAAIAIAAIAAARg");
	this.shape_37.setTransform(-76.2,13.55);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgbA+IAAgRIAHAAQADAAAAgEIAAgyIgLAAIAAgRIALAAIAAgDQAAgSAHgHQAHgHAPAAQALABAGADIAAAPQgBgBgGAAQgHAAgDAEQgCADABAKIAPAAIAAARIgPAAIAAAyQAAAEADAAIAIAAIAAARg");
	this.shape_38.setTransform(-82.15,13.55);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgiAhQgNgMAAgVQAAgUANgMQAOgOAUAAQAWAAANAOQANAMAAAUQAAAVgOAMQgMAOgWAAQgVAAgNgOgAgNgWQgEAHAAAOIAAADQAAAOAEAHQAEAGAJABQAJgBAFgGQAEgHAAgOIAAgDQAAgOgEgHQgFgGgJgBQgJABgEAGg");
	this.shape_39.setTransform(-90.3,15.3);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("Ag0A8IAAgQIAIAAQAEAAAAgGIAAhLQAAgGgEAAIgIAAIAAgQIA5AAQAYAAAMAJQALAJAAASQAAATgLAIQgLAIgZAAIgOAAIAAAaQABAGADAAIAIAAIAAAQgAgJgCIALAAQAKAAAFgFQAEgFAAgLQAAgLgEgEQgFgFgKAAIgLAAg");
	this.shape_40.setTransform(-105.15,13.725);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAKA8IAAgQIAIAAQAEAAAAgGIAAgfIgqAAIAAAfQgBAGAEAAIAHAAIAAAQIg2AAIAAgQIAJAAQADAAAAgGIAAhLQAAgGgDAAIgJAAIAAgQIA2AAIAAAQIgHAAQgEAAABAGIAAAdIAqAAIAAgdQAAgGgEAAIgIAAIAAgQIA2AAIAAAQIgIAAQgDAAAAAGIAABLQAAAGADAAIAIAAIAAAQg");
	this.shape_41.setTransform(-117.3,13.725);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgsAtQgRgQAAgdQAAgbASgRQARgRAbAAQAcAAARARQAQAQAAAcQAAAcgRARQgRARgcAAQgcAAgQgRgAgcgDIAAAHQAAAoAcAAQAdAAAAgoIAAgHQAAgogdAAQgcAAAAAog");
	this.shape_42.setTransform(-130.475,13.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD3type, new cjs.Rectangle(-139,0,262.1,47.7), null);


(lib.HEAD2type = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgEgFAAgHQAAgGAEgFQAFgFAHAAQAIAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgIAAQgHAAgFgFg");
	this.shape.setTransform(22.775,27.725);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_1.setTransform(15.125,24.875);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgiAhQgNgMAAgVQAAgUANgMQAOgOAUAAQAWAAANAOQANAMAAAUQAAAVgOAMQgMAOgWAAQgVAAgNgOgAgNgWQgEAHAAAOIAAADQAAAOAEAHQAEAGAJABQAJgBAFgGQAEgHAAgOIAAgDQAAgOgEgHQgFgGgJgBQgJABgEAGg");
	this.shape_2.setTransform(4.65,24.75);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgsA4QgHgGAAgJQAAgJAEgEQAFgEAHgBQAJABADAGQAEAHgEAIQAKgCAFgQIAAgBIgehBQgDgFgDAAIgFAAIAAgQIAxAAIAAAQIgEAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAAAAAABQAAAAgBABQAAAAAAABQAAAAAAABQABAAAAABIAPAkIAOgkQACgGgGAAIgGAAIAAgQIAoAAIAAAQIgGAAQgEAAgCAFIgaA/QgIAVgHAHQgJAJgPAAQgMAAgHgFg");
	this.shape_3.setTransform(-5.675,26.45);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_4.setTransform(-19.325,24.625);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgiAhQgNgMAAgVQAAgUANgMQANgOAVAAQAWAAANAOQANAMAAAUQAAAVgNAMQgNAOgWAAQgVAAgNgOgAgNgWQgEAHAAAOIAAADQAAAOAEAHQAEAGAJABQAKgBAEgGQAEgHAAgOIAAgDQAAgOgEgHQgEgGgKgBQgIABgFAGg");
	this.shape_5.setTransform(-28.85,24.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgbA+IAAgRIAHAAQADAAAAgEIAAgyIgLAAIAAgRIALAAIAAgDQAAgSAHgHQAHgHAPAAQALABAGADIAAAPQgCgBgFAAQgHAAgDAEQgCADABAKIAPAAIAAARIgOAAIAAAyQAAAEACAAIAIAAIAAARg");
	this.shape_6.setTransform(-36.8,23);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAhQgLgMgBgVQAAgUANgMQANgOAUAAQAWAAALANQALAMAAAXIAAADIg7AAQAAAYAVAAQAQAAAGgPIAPAJQgKAXgfABQgXAAgNgOgAAQgHQAAgMgDgFQgEgGgIAAQgOAAgCAXIAfAAIAAAAg");
	this.shape_7.setTransform(-48.9,24.75);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_8.setTransform(-58.125,24.625);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AggAhQgMgMAAgVQAAgUAMgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQAAAYAVAAQAQAAAHgPIAPAJQgLAXgfABQgWAAgNgOgAAQgHQAAgMgEgFQgDgGgHAAQgPAAgBAXIAeAAIAAAAg");
	this.shape_9.setTransform(-67.4,24.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAGA9IAAgQIAFAAQADAAABgFIAAgjQAAgPgNAAQgOAAAAAYIAAAaQgBAFAEAAIAFAAIAAAQIgwAAIAAgQIAGAAQAEAAAAgFIAAhMQAAgGgEAAIgHAAIAAgQIATAAQANAAAJgCIAAAvQAHgQAVAAQAcAAAAAhIAAAkQAAAFADAAIAGAAIAAAQg");
	this.shape_10.setTransform(-77.7,23.075);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AggAhQgMgMAAgVQAAgUAMgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQAAAYAVAAQAQAAAHgPIAPAJQgLAXgfABQgWAAgNgOgAAQgHQAAgMgEgFQgDgGgHAAQgPAAgBAXIAeAAIAAAAg");
	this.shape_11.setTransform(-92.15,24.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_12.setTransform(-101.375,24.625);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgSAXIAAgOQAEACAEAAQAKAAABgIIgEAAQgGAAgEgDQgDgDAAgGQgBgGAFgEQAFgFAGAAQAIAAAGAGQAGAHAAAJQAAAMgHAHQgIAIgLAAIgLgCg");
	this.shape_13.setTransform(-108,19.425);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AggAhQgMgMgBgVQAAgUANgMQANgOAUAAQAWAAALANQALAMAAAXIAAADIg7AAQAAAYAVAAQAQAAAHgPIAOAJQgKAXgfABQgXAAgMgOgAAQgHQAAgMgDgFQgEgGgIAAQgOAAgBAXIAeAAIAAAAg");
	this.shape_14.setTransform(-114.95,24.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAZA8IgZhIIgZBIIgWAAIgehhQgCgGgFAAIgGAAIAAgQIA2AAIAAAQIgHAAQgFAAACAGIARA4IATg5QACgFgFAAIgIAAIAAgQIA1AAIAAAQIgIAAQgEAAABAFIAUA5IASg4QABgGgFAAIgIAAIAAgQIAsAAIAAAQIgHAAQgFAAgBAGIgfBhg");
	this.shape_15.setTransform(-127.625,23.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD2type, new cjs.Rectangle(-139,0,278,36.3), null);


(lib.HEAD1btype = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgEgFAAgHQAAgGAEgFQAFgFAHAAQAIAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgIAAQgHAAgFgFg");
	this.shape.setTransform(16.025,39.125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAzQgHgHAAgPIAAgsIgLAAIAAgOIAGgBQALgCABgKIACgPIAUAAIAAAaIAQAAIAAAQIgRAAIAAAsQAAALALAAIAHgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_1.setTransform(10.6,35);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_2.setTransform(3.325,36.025);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgiAiQgNgNAAgVQAAgUAOgNQANgNAVABQAVgBANANQANANAAAUQAAAVgOANQgNAMgVAAQgVAAgNgMgAgNgWQgEAHAAAPIAAABQAAAPAEAHQAEAHAJgBQAJABAFgHQAEgHAAgPIAAgBQAAgPgEgHQgFgGgJAAQgJAAgEAGg");
	this.shape_3.setTransform(-6.2,36.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Ag0A9IAAgQIAHAAQADAAAAgFIAAhLQAAgGgDAAIgHAAIAAgQIASAAQANAAAIgCIAAASQAIgTAUAAQASAAAKANQALANAAAVQAAAUgMAMQgKANgSAAQgTAAgIgRIAAAZQABAFADAAIAGAAIAAAQgAgNgPIAAADQABAaAQAAQATAAgBgaIAAgDQABgagTAAQgQAAgBAag");
	this.shape_4.setTransform(-16.9,37.575);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("Ag0A9IAAgQIAHAAQADAAAAgFIAAhLQAAgGgDAAIgIAAIAAgQIASAAQANAAAJgCIAAASQAIgTAVAAQARAAAKANQALANAAAVQgBAUgKAMQgLANgRAAQgUAAgIgRIAAAZQAAAFAEAAIAHAAIAAAQgAgNgPIAAADQAAAaARAAQATAAgBgaIAAgDQABgagTAAQgRAAAAAag");
	this.shape_5.setTransform(-27.95,37.575);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_6.setTransform(-38.875,36.275);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQAAgFgFgCQgDgDgJgCQgPgCgGgFQgLgFAAgOQAAgOALgHQAKgJATABQASgBAPAIIAAAWIgUAAIAAgNQgEgCgIAAQgOAAAAAKQAAAFAGACQADACAKACQAOADAHAEQAKAGgBANQABAOgKAIQgMAJgRgBQgTAAgRgGg");
	this.shape_7.setTransform(-48.4,36.15);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgsA3QgHgFAAgJQAAgJAEgEQAFgFAHABQAJgBADAHQAEAGgEAJQAKgCAFgQIAAgBIgehBQgDgFgDAAIgFAAIAAgQIAxAAIAAAQIgEAAQgBAAAAAAQgBAAAAABQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABQAAAAAAABQAAAAABABIAPAkIAOgjQACgHgGAAIgGAAIAAgQIAoAAIAAAQIgGAAQgEAAgCAFIgaBAQgIATgHAIQgJAJgPAAQgMAAgHgGg");
	this.shape_8.setTransform(-61.975,37.85);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_9.setTransform(-71.425,36.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AghAiQgMgNABgVQAAgUAMgNQANgNAUABQAWAAALAMQAMANAAAVIAAAFIg8AAQABAXAVAAQAPAAAGgPIAQAJQgLAXgfAAQgXAAgNgMgAARgHQgBgMgEgGQgDgEgIAAQgOgBgCAXIAgAAIAAAAg");
	this.shape_10.setTransform(-80.7,36.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgKAtIgehEQgCgEgDAAIgGAAIAAgQIAzAAIAAAQIgGAAQgGAAADAFIAOAmIAQglQAAgBAAAAQABgBAAgBQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAAAAAIgHAAIAAgQIAoAAIAAAQIgFAAQgFAAgCAEIgdBEg");
	this.shape_11.setTransform(-90.7,36.2);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgiAiQgNgNAAgVQAAgUANgNQAOgNAUABQAWgBANANQANANAAAUQAAAVgOANQgMAMgWAAQgVAAgNgMgAgNgWQgEAHAAAPIAAABQAAAPAEAHQAEAHAJgBQAJABAFgHQAEgHAAgPIAAgBQAAgPgEgHQgFgGgJAAQgIAAgFAGg");
	this.shape_12.setTransform(-101,36.15);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgfAiQgNgMAAgWQAAgUANgNQANgMAWAAQATgBALAJQALAHAAAOQAAAKgFAGQgFAEgIAAQgHAAgFgEQgEgDAAgGQAAgMAMgDQgEgFgLAAQgWgBAAAcIAAACQAAAcAVAAQAQAAAGgPIAPAJQgJAYgfAAQgWAAgNgMg");
	this.shape_13.setTransform(-110.725,36.15);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AghAiQgMgNABgVQAAgUAMgNQANgNAUABQAWAAALAMQAMANAAAVIAAAFIg8AAQABAXAVAAQAPAAAGgPIAQAJQgLAXgfAAQgXAAgNgMgAARgHQgBgMgEgGQgDgEgIAAQgOgBgCAXIAgAAIAAAAg");
	this.shape_14.setTransform(-120.3,36.15);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAiA8QgUAAgDgeQAAgLgDgFQgEgGgIAAIgKAAIAAAeQAAAGAEAAIAIAAIAAAQIg2AAIAAgQIAHAAQAEAAAAgGIAAhLQAAgGgEAAIgHAAIAAgQIA/AAQAqAAAAAhQAAAYgaAEQAWAGABAaQABAGABACQACACAEAAIADAAIAAAQgAgOgEIAKAAQALAAAEgFQAGgEAAgLQAAgKgFgEQgEgFgJAAIgNAAg");
	this.shape_15.setTransform(-131,34.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1btype, new cjs.Rectangle(-139,0,278,47.7), null);


(lib.HEAD1atype = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgMAMQgEgFAAgHQAAgGAEgFQAFgFAHAAQAIAAAEAFQAFAFAAAGQAAAHgFAFQgEAFgIAAQgHAAgFgFg");
	this.shape.setTransform(73.325,18.275);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgKAzQgGgHAAgPIAAgsIgMAAIAAgPIAGAAQALgCACgKIABgPIAUAAIAAAZIAQAAIAAARIgRAAIAAAsQAAALAKAAIAIgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_1.setTransform(67.9,14.15);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAFAtIAAgQIAGAAQADAAAAgFIAAgiQAAgPgMAAQgPAAAAAYIAAAZQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAAQQAIgQAUAAQAdAAAAAiIAAAiQAAAFADAAIAGAAIAAAQg");
	this.shape_2.setTransform(59.575,15.175);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AghAhQgLgMgBgVQAAgUANgMQANgOAUAAQAWAAALANQALAMAAAXIAAADIg7AAQAAAYAWAAQAPAAAGgPIAPAJQgKAXgfABQgXAAgNgOgAAQgHQAAgMgDgFQgEgGgIAAQgOAAgCAXIAfAAIAAAAg");
	this.shape_3.setTransform(49.2,15.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAhAtIAAgQIAEAAQAEAAAAgFIAAggQAAgRgMAAQgOAAAAAWIAAAbQAAAFADAAIAGAAIAAAQIguAAIAAgQIAFAAQADAAAAgFIAAghQAAgQgMAAQgOAAAAAWIAAAbQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAARQAIgRATAAQAUAAAFATQAHgTAWAAQAeAAAAAjIAAAhQAAAFADAAIAGAAIAAAQg");
	this.shape_4.setTransform(36.275,15.175);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgKAzQgHgHABgPIAAgsIgMAAIAAgPIAGAAQALgCABgKIADgPIATAAIAAAZIAQAAIAAARIgRAAIAAAsQAAALALAAIAHgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_5.setTransform(24.75,14.15);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgoAoQgHgHAAgKQAAgQARgHQALgFAcgFIAAgFQAAgPgPAAIgJABQACAEAAAEQAAAHgFADQgEAFgGAAQgRAAAAgPQAAgZAsAAQAVABAJAGQAKAIAAAQIAAAmQAAAFADAAIAGAAIAAAQIggAAQgEgGgDgIQgDAHgIAEQgIAFgKABQgNAAgHgHgAgLAGQgIAFAAAIQAAAKALAAQAIAAAEgGQAFgFAAgKIAAgHQgOACgGADg");
	this.shape_6.setTransform(16.925,15.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AghAhQgLgMAAgVQAAgUAMgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQABAYAVAAQAPAAAGgPIAQAJQgLAXgfABQgWAAgOgOgAARgHQgBgMgEgFQgDgGgHAAQgPAAgBAXIAfAAIAAAAg");
	this.shape_7.setTransform(6.95,15.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgpAtIAAgQIAGAAQAEAAAAgFIAAgsQAAgGgEAAIgHAAIAAgQIATAAQANAAAIgCIAAATQAFgTASAAQAKAAAGAGQAGAHAAALQAAAKgFAFQgFAFgJAAQgGAAgEgDQgEgEAAgFQAAgJAIgDQgCgCgDAAQgOAAgBAaIAAAYQAAAFADAAIAHAAIAAAQg");
	this.shape_8.setTransform(-2.275,15.175);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgKAzQgHgHAAgPIAAgsIgLAAIAAgPIAGAAQALgCABgKIACgPIAUAAIAAAZIAQAAIAAARIgRAAIAAAsQAAALALAAIAHgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_9.setTransform(-10,14.15);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AghAhQgLgMgBgVQAAgUANgMQANgOAUAAQAWAAALANQALAMAAAXIAAADIg7AAQAAAYAVAAQAQAAAGgPIAPAJQgKAXgfABQgXAAgNgOgAAQgHQAAgMgDgFQgEgGgIAAQgOAAgCAXIAfAAIAAAAg");
	this.shape_10.setTransform(-21.9,15.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQAAgFgFgDQgDgBgJgCQgPgDgGgFQgLgFAAgNQAAgOALgJQAKgHATgBQASABAPAGIAAAYIgUAAIAAgOQgEgCgIAAQgOAAAAAKQAAAFAGACQADABAKACQAOADAHAFQAKAGgBANQABAOgKAIQgMAJgRAAQgTgBgRgGg");
	this.shape_11.setTransform(-30.85,15.3);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_12.setTransform(-40.475,15.425);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AggAhQgNgMAAgVQAAgUANgMQANgOAUAAQAWAAALANQAMAMAAAXIAAADIg8AAQABAYAUAAQAQAAAHgPIAOAJQgKAXgfABQgWAAgNgOgAAQgHQAAgMgDgFQgEgGgHAAQgQAAAAAXIAeAAIAAAAg");
	this.shape_13.setTransform(-54.9,15.3);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgfAiQgNgMAAgWQAAgUANgNQANgNAWAAQATABALAHQALAJAAAOQAAAJgFAFQgFAFgIAAQgHAAgFgEQgEgDAAgGQAAgNAMgBQgEgHgLAAQgWABAAAbIAAADQAAAcAVAAQAQAAAGgQIAPAJQgJAZgfAAQgWAAgNgNg");
	this.shape_14.setTransform(-64.375,15.3);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAFAtIAAgQIAGAAQADAAAAgFIAAgiQAAgPgMAAQgPAAAAAYIAAAZQAAAFADAAIAGAAIAAAQIgwAAIAAgQIAGAAQADAAAAgFIAAgsQAAgGgDAAIgGAAIAAgQIARAAQANAAAJgCIAAAQQAIgQAUAAQAdAAAAAiIAAAiQAAAFADAAIAGAAIAAAQg");
	this.shape_15.setTransform(-74.575,15.175);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgoAoQgHgHAAgKQAAgQARgHQALgFAcgFIAAgFQAAgPgPAAIgJABQACAEAAAEQAAAHgFADQgEAFgGAAQgRAAAAgPQAAgZAsAAQAVABAJAGQAKAIAAAQIAAAmQAAAFADAAIAGAAIAAAQIggAAQgEgGgDgIQgDAHgIAEQgIAFgKABQgNAAgHgHgAgLAGQgIAFAAAIQAAAKALAAQAIAAAEgGQAFgFAAgKIAAgHQgOACgGADg");
	this.shape_16.setTransform(-85.075,15.3);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgKAzQgHgHABgPIAAgsIgMAAIAAgPIAGAAQALgCABgKIADgPIATAAIAAAZIAQAAIAAARIgRAAIAAAsQAAALAKAAIAIgBIAAARQgIACgJAAQgPAAgHgHg");
	this.shape_17.setTransform(-93.5,14.15);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgkAoIAAgYIAUAAIAAAPQAGABAIAAQANAAAAgKQAAgFgFgDQgDgBgKgCQgOgDgGgFQgKgFAAgNQgBgOALgJQALgHARgBQATABAPAGIAAAYIgUAAIAAgOQgFgCgHAAQgNAAAAAKQgBAFAGACQADABAKACQAOADAGAFQALAGgBANQABAOgLAIQgLAJgRAAQgTgBgRgGg");
	this.shape_18.setTransform(-100.5,15.3);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgSAoIgEAUIgVAAIABgeIAAhDQAAgGgEAAIgGAAIAAgQIASAAQANAAAIgCIAAAxQAJgSATAAQASAAAKANQALAMgBAVQAAAVgLAMQgKANgSAAQgYAAgIgWgAgNAOIAAADQABAbAQAAQASAAAAgbIAAgDQAAgagSABQgQgBgBAag");
	this.shape_19.setTransform(-110.25,13.75);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgrAMIAAgjQAAgFgDAAIgHAAIAAgQIAoAAIAAA3QAAAQAMAAQAPAAAAgXIAAgbQAAgFgEAAIgIAAIAAgQIApAAIAABBQAAAGAEAAIAHAAIAAAQIgTAAQgNAAgIACIAAgPQgJAPgTAAQgdAAAAghg");
	this.shape_20.setTransform(-121.125,15.425);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AguA1IAAgdIAYAAIAAASQAIADANAAQAHAAAFgEQAGgDAAgHQAAgIgHgEQgEgCgQgEQgSgEgIgIQgKgHAAgQQAAgSANgLQANgKAWAAQAWAAATAIIAAAdIgYAAIAAgRQgIgDgIAAQgUAAAAAPQAAAHAGADQAFADAOADQATAFAIAGQAMAIAAAQQAAATgMAKQgNALgXAAQgZAAgUgJg");
	this.shape_21.setTransform(-131.725,13.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1atype, new cjs.Rectangle(-139,0,278,47.7), null);


(lib.CO_v_white = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgyA1QgXgVAAggQAAgeAWgVQAVgWAeAAQAfAAAWAXQAVAVgBAdQAAAfgVAVQgVAVgfABQgdgBgVgUgAgvgvQgTAUAAAbQAAAcATAUQAUATAbAAQAcAAATgTQATgTABgdQAAgbgTgTQgUgUgcAAQgbAAgUATgAASAuQgCgDgCgKIgCgPQgCgIgFgEQgEgCgJAAIgGAAIAAAqIgRAAIAAhcIAfAAQAPAAAFACQAPAFAAARQAAAQgTAGQAGABADAEQADAEABAJQAEAVADAHgAgOgIIAOAAQATAAAAgNQAAgIgHgDQgDgBgMAAIgLAAg");
	this.shape.setTransform(133.8251,86.6356,0.4949,0.4949);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("ACmLBQgKgEgNACQgPADgIAAQAAgDgKgCIgOgBQgRABgHgCQAAgDgSACQgjgBAAgBIgUgCIgTgBQgLgCgHAAQAAgBgQABQgRABAAgDIgOgEQgJgDAAAHQgDAAgFgDQgEgDgDAAQAAAFgJgBIgNgDQgNgCgLACQgRACgYgKIgJgEQgEgCgEABQgCAAgIgEQgIgFAAgBIgMABIgMABQgIACgFgBQgDAAgDgEQgEgFgDAAIAAAEQgEAAgEgCQgGgDAAgEQgCAGgBAAQAAgDgIgDQgIgCgFAAIgBABQgBAAAAAAQAAgBAAABQgBAAAAAAQAAAAAAAAQgDABgFgEQgEgDgEABQgEABAAgDIgIgGQgHgFAAAEQgCABgMgFQgNgGAAgCIgTgJQgBABAAAAQgBABAAAAQAAABAAAAQAAAAABAAIgEABIAAAAIgEAAIAEAAQABADgQgGQgCgDgFAAQAAgGgDgCIAAAGIgFgDQgGgDAAADIgIgIIgOgCQAAgCgNgGQgNgGAAgCQgKgEgDgKQgBgDgJgBIgOgCQgTgKgBABQgEgCgCABIABgDQgCAAgQgKQgLgIgDgIIgLgDQgCgCgBgDQgBgBgFAAIgDgHIgCgHQgEgBgCACQgCACgCAAQgBgLgTAAQgPAAAAgBIgNgBIgMgBQgSAFgHgCQAAgBgYgBQgaAAgDgBQAAACgJgCIgNgDQgLAFgDgEQgNgEgCABQAAABgGAAIgHgBIgJgCQgDgCgFAAIgOABQAAABgOgEQgGAAgFgHQgCgBgNABIgMAAQgEABgcgDQgcgDAAgBIgJgDQgGgCgDAAIgXgDQgDgEgbgGQgagHAAgBQgCAAgEgCQgDgDgDABQgOACAAgEQgJgEgPAAQAAgFgKgBQgNgBgBgBQgLgFgFgDQgHgGgQgDIgYgEQgDgDgDABIgHACIgGgDIgHgCQAAgEgJgBQgJgBgCgFIAJgCQgBgEgMgEQgMgFAAACIgSgJQgFAAgIgGIgLgHIgMgEIgNgBIAVAVQAAADAHAGQAHAGABAEQADACAGAHQAGAGAEABQAKADAEAHQADAAAHADIAKAFIAHAEQAHAEAAACQAFAAAHADQAGADAEAAIAEACQABAAABABQAAAAABAAQAAAAAAABQABAAAAAAQAFABAGAGQACAFAWAEQAVAEAAADIAYAKQADAAAGADQAFAEAEAAQACgBATAGIATAFQADAAAIAEQAGAEAEgBQAEgBAJAEQAKAEADAAQAAgBARAEIAVAFQAEAAAJACIANAEQAAABAOACIAQABQAAAFBNAGQADADAjADQAiAEAAABQBPAIAAgBQADgBAkAEQAiAEAAgBQAIgBAAABQgGAAgMAGQgOAGgFABIgMgCQgLgCAAADIgGABQgDABgDgBQAAAGgUABQgTABAAgDQgQACAAgCIgGACQgBAAgBAAQgBAAAAAAQgBAAAAgBQAAAAAAgBIgLgBQgDgBgDgGQgDAAgCADQgBABgGAAIgNgBQgXgCgDgCIgFgFIgJABIgMgEQgKgDAAADQgGAAgKgCQgCgGgEABIgJAFQgFADgFgCQAAgCgLgCQgKgCgEABQAAACgWgEIgbgFQAAgCgOgBQgPgBgBgEQgHAAgLgDQgMgDgGgBQgCgCgNgBQgNgBAAgCQgGAAgJgCIgOgEIgNgEQgNgEAAgBIgNgCQgKgCAAgBQgFAAgGgCIgLgFIgDgBIgCgBQgLAAAQALQACACAGACQAGACADADIAKADQAAABAFABIAHABQAAACASADQAAADAaAEQAZAFABAHIgKACQAAgDgXgDQgZgDgCgDIgagHQgVgHAAgDIgZgIQgUgIAAgBQgIgCgKgEQgNgGgFgGIgIgFQgJgEAAABQgCAAgHgFQgIgFAAgCQgKAAgPgHQgRgJgCgJQgPgKgGAAIgIgIQgFgFgDgCIgGgIIgJgFQgGgCAAgDQgGgEgHgIQgHgJgDgGQgDgBgEgHQgFgHAAgCQgDAAgDgJQgDgKgEAAQAAgEgDgGQgEgFAAgFQgBAAgFgTIgGgYIgHgkQgHgjAFAAIgFgVQgBAAgBgLIgBgNQgDAAAAgNQgBgOgCAAIgJhUIAAggQAAgcACAAIgCgjQgBggAEAAIgCgxQgCgsAFgDQAAgEAKgaQALgZgBgEQAIAAAHgOQAHgPAGgCQACgBADgFQACgGADgCQAAgFAGgGQAHgGAHgBIgDgEQAAAAAAgBQAAAAAAgBQAAAAABgBQABAAABAAIAEgCQAAAAAAAAQABAAAAgBQAAAAAAgBQAAAAAAgBIAHgHIAKgHIAFAAIAEgCQALgIgHAAQgCgGAFgEQAFgFAFAAIAIgDIAIgCQAKgFAKgJIAQgRQAGgGADgBIAFgDIACgEQACAAAOgLQAAgCANgFQANgGAAgEQAEAAAJgGQAJgHABgDIAOgJQAHgEAIAAQAAgBAGgDIAFgCIAJABQAGACABgDIAXgEQAOgEAAgJQADgBACgEIADgEQABgCAEgDQAEgCABgDIgBAAQAAgFAHACIAJACIARgCIAIgFIAKgEIAJgFQAHgEACAAIAEgCQABAAAAgBQABAAAAAAQABgBAAAAQABAAAAgBQAFAAAFgCQAHgCAAgDQgHAAAHgHQAHgGAEgBIANgHQAFAAAGgDQAAgDAHgCQAGgCAAgEQAGAAAAADQADAAAEgCIAHgCIAKACQAGABACgDIAOgGQAJgGAEAAQAAgBALgEQAKgDAEAAQAAgCAHAAQAHAAAAgBQAJAAACgCQACgBAAgHIAFgDIAEgEIAJACIgBAFIAEgCIADgCQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAfAAAHgDQAEgBAGACIAKACQALgGgFAAQgCgJASgGQATgGAAAFQAMgIAZAAQACgDAJAAQAJABACgEIAXgEQAUgEAAgBIABABIAVgFQAWgFADAAQAVAAAAgEIAIgCQAHgBAAgBIAggHIAvgHQAOAAAggFQAggGAQAAQAAgFBQAAQAAABAGACQAHACAAACQgIAFgXgCIgQABIgRABQgJAAgRADQgSADgJAAQAAgChXATQAAAFArgFIAxgGIAugGIAbgDQARgCAJACQAUgDABAKQASAAAAABIAHABQAAAAAAAAQABABAAAAQAAAAAAABQAAABAAABIgIAAQAAADg1ACQAAABgRADIgUACIgTAAQgSAAAAADIgwAHIgSACIgUACQAAADgMACIgQACQgIgBgPAEQgQAFgHAAIgMACQgMACAAACQgEAAgGAEQgHAEgDAAIgJAAIgJgBQAAADgQACQgPADgBADQgCAKgMADQgOABgIACQAAADgTAHQgHAKgHAEQACAIAiABQAfABAHgEQADgCAagEQAXgDAAgCIAMgCIAMgDQAAgBAGABIAHABQARgEAJAAQAAgBAcgDIAcgFQAfgDAAgBIAVgCIAWgCQAAgCAmgCQAngDAFABIApgDQAkgDAAACQAMgCAYACIAcgBQASgBALACQAAADAJACQAJACAAgCIAQABQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQADgBAKACQALADAAACQgEACgWABIgVAAIgmABQgCADgWAFQgVAFAAACIgQgBQgPgBAAACIgWAAQAAAFgZABIgegBQAAADglABQglACgBAIQARADAXgDIAngGQAAACAkgCQAjgBAAABQAFAAALgDQAEAAAEACQAFADAEAAIAQgBQAJABgEAGQgFAIghACIghACQhWAFAAADIgTACQgTACAAgCQgGgBgJADQgLADgDAAIgRACQgCACgGAAIgKgBQgGABgJAGQgIAGgGABQAAAFgdAEQAAABgHACQgIADAAABIgTADIgKACQgLACgBACQgRAAgMAMQgGABgKAFQgKAGgGABQAAgBgNAFIgPAFQAAgCgFABQgEAAgCACIAEABQgBADgMACIAAgEIgOAFQAKAIgUAEQgWAEAAACIgTAGQgNAFgGABQAAgCgvAQIgRAGQgRAGgCADQgTAAgDAEQgFAAgHAFQgGAEgFgBQgGAAgFAFQgGAGgFAAQgCgDgFACIgIAEIgKAFQgFACgFABQgBABgLADIgNACQAAAFgJACIgOADQgBAAAAAAQgBAAAAAAQAAABgBAAQAAABgBAAQgCADgEAAQgEAAgCADQgDAEgDACIgDADQgBABgEAAQgBgCgGgBQgFgCAAAEQgFAAgBAFQgDAHgCABQAAADgJAAQgOAJgCAAQAAACgMACQgLADAAAEIgMAGQgIAFAAADQgFABgFAEQgGAEgEABIgGADQgEACgCAAQgRAJgCAAQgEAEgFAAIgQAMQAAADgIAFQgIAEAAADQgGAEgOACQgBAEgEACQgFACgBABQgFAAgEAIQgEAHgDABQgEABgIAHQgIAFgDAAQAAAFgHAEQgIADgBAFQgSALgLANQgEAAgGAGIgIAKQgGAIgFADQgBADgFACQgFACAAAEQgCAAgHAJQgGAIgDAAIABADQgFAAgFAHIgHAKIgIAIIgHAJQgDAHgLANQgJALgBAJQADAAAGgHQAIgJACgBQAGgKAEAAQAAgDAHgFQAGgFABgCQgCAAAKgJIALgJQAGAAAEgJQAEgJADAAIAGgGQAGgFACAAQACgEAHgEIALgHQAAgCAEgFIAHgFIAVgPQADgHAUgGQABgDAJgEQAIgEAAgCQgBgEAGgCIAIgDIAWgOQAEAAAFgFQAGgEADAAIAhgUQAGgCARgIQATgJAAgDQAHgBACgDQAEAAABgDQACgDACAAQAHgCABgCIAIgEQAFgDAAgBIAGgDIAFgDQAAADAMgFQALgFACgDIAHgCQAFgCAAgBQAHgBAOgJQANgIAIAAQADgEAJgCQAIgCADgDQAEAAAGgEQAFgEAEAAQAFgFAIAAIAIgIIAHAAIAGgBIASgHQAAgBAGgCIAHgBQADgEAKgBIALgCQABgCAHgDQAIgEAAgCIAQgDQAAgCALgDQAJgCAEAAQAAgGANgBQANgBACgCIApgMQAhgJAAgFQAEAAASgFQARgGAAgBQAFAAAJgCQAKgCAAgEQAygGAAgEQALAAAQgFQATgHAHgBQAAgBAYgFIAbgFQAAgBAdgGIAhgHQAIgCANgBQAAgBAFgBIAHgBIATgEQAMgDAHABQAAAIgWAFIgeAFQgQAEAAACQgDAAgHAFQgHAFgFgBQAAAAgBgBQAAAAAAAAQAAAAgBAAQgBAAAAAAQAAACgZAIIgHAFQgEADgEAAQgDAEgGABIgMABIgbAJQgQAFgMACIgEADQgEADAAACQgEAAAFAEQAFADAAgEIAMgBQAKgBAAgCQAfAAgQAFIgHAEIgGAGQgCABgHgCQgEgBgCAGQgJgBgIAEQgKAEgIAAQgFAAgHAEQgGAEgEAAQAAAEAGAAIAGgCIAHgCQAAANgmACQgBADgGABQgDACgEgBQgEAAgDABQgBACgPAFQgFAGgSAAQgLABgBAGQgEgBgFACQAAAAgBABQAAAAgBAAQAAAAgBAAQgBAAAAAAQgEgCgBABQAAABgFAEIgIAEQgOAFAAACQgBgBAAAAQgBgBAAAAQgBAAgBAAQAAAAgBAAIABACIgGACQgEACgCgBQgBAGgKABIgOgBQAHAFgHADQgFACgGAAQAAgBgIAEIgIAEQgDAGgPAAQAAgDgGACIgEADQgBgDgEAFIgEAIIgGgCQgBAAgBAAQgBAAgBAAQAAAAgBABQAAAAAAABQgFACgIAAQgEAAgMACQgNADAAADQgDAAgEAEQgFAEgDAAIgbAKQAAAAAAAAQgBABAAAAQAAAAAAABQgBAAAAAAIgDADQgEAAgDACQgDACgCAAQAAADgEABQgEACgDAAQgFgBgDAEQgEAFgDAAIgHAEIgFADQAAAGgKACIgOABQAAABgFADIgHADQgDABgHAIQgFAHgGgBQgHgCgJAJQgRAEgBADIgFACQgCABAAAEIgJgBQABABAAAAQABAAgBABQAAAAAAAAQgBABgBAAIgEAAQgBAAgBAAQAAAAAAABQgBAAAAABQAAABABABQAAAGgKAAQgCgCgGADIgJAEQgRAHgIAKQgJABgIAEIgPAJQAAAEgMAGQgMAHgCAFIgJAEQgGACAAAEIgMAFIgGACQgDABgCADIgCADIgEACQgJAHAAACQgDAAgCADQgDAEgCAAQgHABgFAEIgNAPQgHAIgJADQAAAGgOAJQgOAKAAAHQgEACAOALQAPANgBADQgFAAgGAKQgFAKgBAGQgDAAAPANQAPAMAAgEQAGAAAIAHQAIAHABAGQAAAEAKACQAKACACACIAMAJQAGAAALAGQALAFAGAAQAAAHArAAQAMAMAIAAQAAABAIAAQAJABABABIALAAQAGABAFADIAOAJQANAGAFgCIAKgCIALgCQAEADACAAQgCAEADACQACABANgBQAMAAACAEIATABIAIABIAJABQAAgCAPADIASADQADgEAGAAIALAAQABACAHAAQAHAAADADIAEAKQAEAIADgBIACAAIABgCIABgNQABgFAFAAIAKAAIAPACIARAAQAAgCAKADIAMAEQAAgFAKgCQAKgBAAAGIAugFIgBgCQADgCgDgPQgEgPABAAIgEgNQgFgMABAAQABgCgBgFQgBgFgCAAIgBgUQgBgFACgMQABgOACAAIAAgDQgBAAAAgBQAAAAgBAAQAAgBAAAAQAAgBABAAQAFAAAAgZQACAAACgIIADgJQAAgFADgGQADgHABgFIAIgfIAIgQQAFgKAAgGQAEgCACgGQADgIADgCQAHgGgBgHQAMgMgBAAIAEgGQADgCACgEQgCgFAEgBQAAgCAFgGQAGgFAAgDQACgBAFgGQAFgHACAAQAAgDAFgDIAIgGQACAAAEgEQADgEAAgCQANgGAPgPIAFgCQAAAAABAAQAAAAABABQAAAAAAABQABABAAABIgRANQgFACgFAIQgFAHgBAFQAGgBADgDIAGgIQAPgGAAgBQAIgCANgKQALgJAKAAIAIgBQADAAADgDQABgBAAAAQAAgBABAAQAAgBABAAQABAAAAAAQAAgDAEgBQAAgDAJgHQAIgHAFgCQADgBAFgEIAIABQACgCAFAAQABAAABAAQABgBAAAAQABAAAAgBQAAAAAAgBIAIgGQAHgGAAADQAGACAAgLQAGgBAFgEQACgCAJgCQAAgDACgDQADgDACAAQAAgCAMgGIANgHIACgFQABgCAEgBIAGgCIAGgFIAFgBIAFgCQAEgEAHgDQAIgDADgDQAFgEADACIAEADQADAHgOAHIgSAIQAAACgSAJIgMAJQgIAFgCAFQgEABgIAGQgIAGgGABQAAAIgLACIgMAJQgGAFgCAFQgIACgHAIQgCAAgDADQgDACgEAAQgGABgCAHQgIAEgCAJQgEACgEAFIgIAIIgPAMQgKAHAAAHQgNAGACANIgDAEIgCAGQgFACgBAJQgCAAgEAFIgFAFQgJAKAAgEQgDABgBAHQAAAGgIAAQAAABgEAEIgFAEIgBALIgGAJQgEAGgBAEIgMAKIgEAMIgGAEQgBACABAFQgBAAgEAHIgDAJQgDABgFAIIgHAHQAAATgIADQgGACABAJIAAANQgEAAgBAZQgBAZABAAQABgJAIgNQAKgOABgHQADAAAFgIQAEgGAAgDIALgUQACgBAFgIQAEgHAEAAQAEgPALgCQgCgKAMgGIANgPQABgEAJgIQAIgHAAgFQAFgCAGgIQAFgJAFgCQAAgDALgJQAJgIAFgDQAAgDALgHQAKgGAAgCQAGgEANgNIAPgNQAEAAADgFQADgFAEAAQACgEAHgGQAHgFAEgBQABgDAFgEQAHgEABgCQAIAAALgMQAMgMAGAAIAKgHQAIgFAAgCQADgBABgDQAAAAAAgBQABAAAAAAQABgBABAAQAAAAABAAQAIAAgCgGIAGAAQAAgCARgIQAQgJAEgBQAAgEATgKQARgJAGAAQADgGAJgFQAIgEAHgCQAAgBAJgEQAJgEACAAQACgCAUgJQATgIAAgBIAEgEQAAAAABgBQAAAAABgBQAAAAABAAQAAgBABAAQAAAAAAAAQAAgBABAAQAAAAABAAQABAAABAAIAGgBQAAgCAIgDIAIgCQADgDAIAEQACgJAFAAQAGgGAIAAQAAgCAHgCIAKgDQAFgHAZgGQABgCAGgBQAFgCACgCIAGgCIAHgCQAAgCAGgBQAGgBAAgBIAEADIAdgQQAAgBAMgDQALgCAAgCQAXgGAAgCIAJAAQAHAAADgEQADAAAPgJQABAAABAGQAAgIAVgEIAMgEQAJgDABAAQAQAKgEgHIgCgDQgBgBAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAQAAgBAugJQACgEAXgEQAWgEAAgBIAIgDQAEgCADAAQAAgDARgBQATgCABgCQADAAADgDQADgDADAAQAAgCALAAQAngIADABQAAgCAvgIQAHABANgDIAVgGQAYgFAGAAQA9gJAGAAQAJgBAVgEQATgEAMAAQgBAAAAgBQgBAAAAgBQgBAAAAgBQAAAAAAgBIAKAFQAIADAAgGIAUgCQA+gHAAACQADABAZgFIAigBQAfAAAAgCIBjgBQAAgCAoADQAsAEAEAAIAKAAQADAEAEgCIAIgCQACAHgDgBQgBAAgBAAQgBAAAAAAQAAAAgBABQAAAAAAAAQgFAEgNAAQAAAAAAgBQAAAAgBAAQgBAAAAAAQgBAAgBAAIgFACQgEAAgDgCQgDgCgCAAQgNAHAAgEQgQACgIgCQAAgCgMABQgMACAAABQgLAAgKABQgCAFgGgCIgKgDQAAADgLAAQgKgHgCACIgDADIgFABQgDADgGABQgDAAAAAHQgMAAgCAIQgCAIAMAAQACADAKABQAKABADACQAAgFAHADIAKADQAAgEANACQAIABgDACIgFADQgCACgJAAQgIAAgEgCQAAABgHABQgGABgBAFQABAAAAAAQABAAAAABQAAAAAAABQAAAAAAABIgCADQgKAAgIACQgKADgHAAIgqADQgCAEgLAAIgRAAIgtACQAAABgfAEQggADgFgBQAAAGgzgBQAAABgIADIgJACQgYAAAAADQgFgBgOADIgiACQAAABgVAEIgYADQAAgDgKAHQgLAGAAACIAhAAIAbgEIATACQADAAAFgCQAEgCAFAAIAOgDQANgCAAACQAFABAHgFIAOABQAAAFALgHQAKgBARgDQAAgCAJAAQAGgBAFABQAGACAGgBQAGgCAFACQAAgDARgDQARgEAAAFQArAFAAgDIAJABQAGABAAADQgNAHgDgBQgFgBgKABQgLABAAADQAkgDBBACQANAAAaAEQAYADANAAQAlAAA5AKQArAFAAAFQAFAAAXAFQAZAFAAADIAIAAQAEAAABgEQAJgDAFAAQAFAAAFACQAAABAIACQAIACAAACQATAAAZAOQAPASgBAAQAAAGASAAIgLgKQgIgHAJAAQAGAAAJAFQAJAFAFAAQAqAWAEAAQAAABAPAEQAOADAAADQADAAAHAEQAIADADAAQAAABAoAOIAZAOQASALAAAHQAEAEAFACQAAACAJAIQAKAIAAADQAHAMACAAQAAADAEAGQAEAGAAAEQABAAACAHIACAJQAEAAAFATQAFATADAAIAJAUQAFAMAAAKQACAAAFAbQACAAAGAXIANAyIAHAaQAHAXgDAAQACAGADApQABADgCAFIgCAIQgCAAAAAGIAAAJQgCAAgDAIIgDAJQgDABgFAPIgFAPQgBADgDAAIgDAAIgBAGQgBAAAAAAQgBABAAAAQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQAAAAgBABQAAAAAAAAIgIAAIAAAEQAAAAAAABQAAAAAAABQgBAAAAAAQgBAAgBAAQAAABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQgEACgBAGQgCAAgDAGQgDADgCgFQgHABgFAFQgEAAgCAIQgCAIgCABQAAAHgGADQgGADgGgCQABANgJgDQgMgEgCAEIAAAMQgCABgDADIgCADIgEACQAAAAgBAAQAAAAAAABQgBAAAAAAQAAABAAAAIAAAGQAAABAAAAQAAABgBAAQAAABgBAAQAAAAgBABQgJgCAAABIgKAEQgEAAgCADQgCAAAAAFQgBAFACAAQgBAKgNABQAAgDgIgBIgLgCIgGADQgGACAAADQAAADgMACQgEABgKAFQgKAFAAADQgCAAgNAHQgNAHAAACQgFACgDAHQgCAFgHgCQAAACgDAEQABAAACAEQACADAAACQgGACgLgDQgLgDgFABIABAKQAAAGgFAAQgCgDgEACQgBABAAAAQAAABAAABQgBAAABABQAAAAABAAQADACABADQgEACgFAAIgJAAQgCAAgHgFQgHgEgFAFIgDAGQgBACgEABIgHAEIgFADQgBAFgJAAIgPgBQAAAHgJADQgLADgCADIgDADQgBABAAAAQgBABAAAAQgBAAAAAAQAAAAgBgBQgCgDgDAAQgEgBAAAEQgBAAgBAAQgBAAAAAAQgBAAAAABQgBAAAAAAIAAAGIgMABQgDAAgGAFQgEADgDgHQgDgBgDAFQgDAEAAAEQgFAAgFADQgFADAAAEIgGgBIgHABQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAABgBAAQAAABAAAAQAAABgBAAQAAAAgBABQAAAAgBAAQgBAAAAAAQgBABAAAAQAAABAAAAQAAABAAAAIAAADQAAABAAAAQAAABAAAAQAAAAAAAAQAAAAgBAAIgEAAIgPADQgFAGgHACIgPACQAAAAgBAAQAAABAAAAQAAAAgBAAQgBAAAAAAQgBAAgBAAQgBAAAAAAQgBABAAAAQgBAAAAAAQAAADABAGQAAAEgNgEIgHAFQgHAEAAADIgJgBQgEABgCAGIgJADQgHABgCgEQgGADgHAFIgMAIQAAAGgRgDQgSgDAAAIIgFgCQgBgBgBAAQgBAAAAAAQgBAAAAABQgBAAAAABQgBAAgDAFQgDAEgCgBQAAAAAAgBQAAAAgBAAQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQgBgBAAAAQAAAAAAgBIgGAHQgDAFgFgBIgEAAIgFACQAAAAgBABQgBAAAAAAQAAAAgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQAAAAgBAAIgFAFIgJAEQgHADABABIAYAAQAOgBAIgDQADgBAcgFQAYgFAAgDQADgBAFAGQAEAGAEgCIARgFQACgFAZgDQAAgBALgDIALgEIALgCQAJgBgBgDQARgHABAHIAPgGQAKgDAHABQgSALgFABIgpAUQABgGgKACQgIABgEAEIAEADQgEAAgUAIQgUAIAAACIgJABQgIACAAADQgFABgFgBIgJgDQgBAKgHgBQgMgBgCABQAAABgIABQgJAAABAEQgRAJgKABQgWADAAACIgIABQgGgBAAgBQgDgBgEABIgHACQgWAMAAgIQgDAAgEACQgFABgBADQgDgBgIADIgGADQAAABgVAEQgGAAgFAEQgGAEAKABQAAAAAAgBQAAAAABAAQAAAAABAAQAAAAABAAIADABQAAgDARAAQAQgBAAgCQAIAAAWgHIAdgEIAkgGIAVgEQATgEAAABQAIAAAMgEIASgHQgBgBAOgFIAQgEIAVgIQAPgHAEAFIgUAKIgRAHQgGABgLAGQgMAFgEABQABADgKACIgNACQgKAGgLACQAAgCgMAIQgCAFgDgFIgDgDQgEABgFADQgFAEgDAAIgKADQgJABAAADQgFAAgGACQgGACgGAAQAAAJgLgMQgCAGgBAAQgDgFgJACIgLADQgFAGgBADQgFAAgEgDQgFgDgEgBQAAAFgGAEIgLAEQgXALgNgLQgMAEgDAAQAAAHgPAAQAAACgMADQgLADgEgBQAAgEgIAAIgMAAQgCAHgBAAIgHgBQAAACgVgBQgBAAgBAAQAAgBgBAAQAAAAgBAAQAAgBAAAAQgBgBAAAAQgBgBAAAAQgBgBAAAAQgBAAAAAAQAAADgJAAQAAgGgEAIIgDAEIgIAEQAAgEgHABIgIACQgCABgQAAQgOAAgBADIgYAAQgFAAgHgDIgMgDQgHAHgIAAIgRgDQAAABgKADQgKACAAABIgPACQgMACgEgEQAAgBgNAAIgRgBQAAAFgHgBIgKgCQAAADgPABIgFAAQgKAAAAgDgACUKCQAAABAAAAQABAAAAABQABAAAAAAQABAAABAAIAEgCIAdgDQAZgCABAEQABAAAAAAQABAAAAgBQAAAAABgBQAAAAABgBQACgDADAAIAEAAIADgBQAEgBAGABQAHAAADgBIAOgFQAJgCAHAEQABgGAEADIAFAFQADAAAFgFQADgGAEABIAHACQADAAAFgDQACgBAFAAIAHgCQAFgBABABIABAFQAEAAAEgGIAJgDIASgFIALgBQAHgBAEgDQALgFADAAQgFgBgPAEIgTAGIgfADQgPACgVgBIgWAEQgSACgBgEQgNACgBABQgKADgJgCQgKgDgNACIg1ADQgFABgCgFIgKADQgBgDgFgBQgIgBgCgCQgLAEgEgBQgMgDgagBIgagBQgFAAgJgCIgOgBIgMAAIgKgCIgBACQgBAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAQgDgCgCABQgBgDgFgBIgHAAQgKgDgYgBIgOgCQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAgBABIgDABQgLABgIgDIgFgDQgCgCgDABIgNAAQAAgCgFAAIgHAAQgDgBgEAAIgIAAQgEAAgDgCIgGgEIgPgDQgJgBgEgEQgFgEgBAAQgCACgEAAIgKgCQgGgBgEABQgBgEgMgDQgIgCgGAAQgDABgDgDQgCgCgDABQgDAAgGgBIgKgEQACABgSgIQgQgHAEgBQgCgBgHAAQgGABgDgCQgIgEADgCIgQgFQgDgBgPADQgRADgOgBIApAdQARgBALAEIANAFQAIgBAMAGIAMAFQAKAEAAACIAHgCQADgBACADIAGAHQACgBAIgBQAJgBABADQAAAAAAAAQAAABAAAAQgBAAAAAAQAAAAgBAAIASAGQADACAFAAIAIABIASAFQAEACAFABIAJABQAQAEAjAEQA8ALA6AFIAbACQARABALACIAhABQADgBALACIAQABIAMgBQAIgBAEACQABAAAAAAQAAAAABAAQAAAAABgBQABAAAAAAIABgBQABAAAAAAQAAABABAAQAAAAAAAAQAAABABAAgAGCH/IgCgHQAAgDAHAAQABABAHgBQAHgBABgCIAPADQALACAAgEQAGgHAHAFIAMAHQAGAAAAgDQgBgEADgCIAHgCQACAAACAEQAIgIAQgBQAJAAAQABQAAgBAFgCIAGgDIARAAQAAgCAPAAQACAGAEAAQAAgGAIgBQAHgCAAACIAJgCIAJgCQAAAAABgBQAAAAABAAQAAgBABAAQABAAABAAQADAAACgDQALgFAIADQACAAATgEIAGACQAAAAABAAQAAgBABAAQAAAAAAgBQABgBAAgBQAAgBAAgBQABgBAAAAQAAAAABAAQABgBAAABQAFACABgBQAAgCAPgDIARgDQABgCAOgFQANgFAEAAQADABAEgEQAEgDADAAQAAgDAQAAQAGABALgHQAGAAALgFQALgGAGAAQACgDANgEQANgFAFAAQABgCAMgEQALgDAAgBIAVgIQADAAAEgCQAEgDAEAAIAKgEIAHgDQAEgCAEgBQABgDAGgBQAGgCACgCQAEAAAIgDQAJgEACgCQAEAAAHgEQAHgEADgEQAFAAAJgFQAIgFAGAAIAYgMQAAgBAVgIQAWgJACgDQAFAAAJgFQAIgGAGAAQAFAAAGgGQAHgHADAAQAEAAAGgGQAHgGADAAQAHAAAKgIQAEgCAHgHQAAgBAGgCQAGgCAAgCQgHAAAGgCQAFgCADAAQAAgEAJgBQAHgBADABQAAgDADgEQADgFAAgFIAQAAQAAgEAEgCIAIgFIANgIQAAgFAMgGQALgGAAgCQAMgCADgDQAGgEADgJQAFgBAQgbQAMgGAGgKIACgEQABgBAAgBQABAAAAAAQAAgBABAAQAAAAABAAQADAAAFgJQAFgKAFAAQADgFAAgJQAFgDgBgEQABAAACgMQACgNACAAQAAgBgCgFIgEgGQAAAHgLAAIgFAGQgEAGACAAQAAADgHAGQgIAFAAACIgFAGIgGAIQgDAAgFAFIgIAFIgFADQgFADABAEIgJADIgHADIADAAIgBAEQADAAgMAKQgDADgIAAQgHABgCACQAFAAgFAHQgFAGgEAAQgJAMgOADQgEAIgOAFIgCACQgBAAgBAAQAAABgBAAQAAABAAAAQAAABAAAAIgKABQgCABAAAHQgbAFAAAGQgPALAAABIgJADQgGACgEAAQAAADgFACQgEACgEAAQgEgGgEAHQgEAHgCABQAAACgKAGIgMAGQgEABgIAGQgJAGAAAEQAAACgMAEIgQACQAAAEgJACQgJABABAEQAAABgaAFQAAAHgOAGQgLAFgKABQAAgFgOAHIgOAGQgDAAgJAEQgIAEAAABQgEAAgHADQgHADgEAAQAAACgJAEQgIADgCgBIgBADIgBADQgBAAAAAAQgBAAAAABQgBAAAAAAQgBAAAAABQAAAAAAABQgBAAAAABQAAAAgBAAQAAABgBAAQgDABgCgCQAAgBgBAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIgIAFIgDAAIgCgBQAAADgFABQgGABAAABQgEACgCgBQgDAAgDACQgDADgMAAIgIAGQAAABgKADIgNADQgNAGgDAAQAAAAgBAAQAAAAAAABQgBAAAAAAQgBAAgBAAQgBAAAAAAQgBAAgBABQAAAAgBAAQAAAAAAABIgYAKQgYAGgGAEQAAADgXAAIgHAEQgEABgBAFQgFACgEgBIAAAFIgPAAQAAAGgGABQgHACAAgCQgDAAgLAFQgJAEgFgBQAAgBgGACIgHACQgDADgIAAIgMgBQgCAEgLAAIgbAJQAAABgFACIgJADQgFADgKAAQgDgDgDACIgFAEIgKgDQAAAHgNABIgTABIgIABQgFACgBADIgMgBQgcALgDgBIgUACQgSADAAACIgPADIgOACIgHACQgFACAAABQgIAAgQACQgVAEgDAEQACgCATAAQAAAEAZAAQADgEALABIAQACQAAgEANACIAOABQACAAADADQADACADAAIAAAAgAn2HeQgCAEgDAAIANAKQAJAGAEAAIADgDQABAAAAgBQAAgBAAAAQgBgBAAAAQgBgBgBAAQgBgDgGgFIgKgFIgDgCIgCACgAAUGwQACAEACAAIAIACQAFABACgEIADgBQAAgBAAAAQABgBAAAAQABAAAAAAQAAAAABAAQAAgBAHgBQAHgCAAgBQAigBAAgFIAGABQABAAAAAAQABAAAAAAQABAAAAAAQAAgBAAAAQAFgBANADIAJgDQAGgDADAEQACADAFgBQAFAAACgDQACgCAFACIAIACIgEgEIADgGIAKgCQAGAHAAgFIASABQAFgCAHgHQACgBAKABQAJABADgDQAEgEAHAAIALABQACgFALABIAOABQAAgDAHABIAJADQAAABAKgHQAKgBAOACQAAgIAPgBQAAgBAVgEQAVgFADABQABADAMAAQAMAAACgEIACgFQAEgEADAFQACABAEAAIAGAAQAAgIABgCQACgBAIABQABAEAHgDIALgDQAEgBAKAEIAIgEQAAgFANgDIARgCQAHgDAEgGQADgCAHABIALABIgBgFQAEAAABgCQACgDADgBQADgBADABIAHACQAAgCAPgCIASgBIgCgEIADgBQAAAAAAAAQAAAAAAABQABAAAAABQAAAAAAABQAJgBAHgEQAJgHAFgCQAXAAADgFQANAAABgCQAGAAgDgGIAKgBIAEgGQABgBAAgBQABgBAAAAQABAAAAAAQAAAAAAAAQADABADgCQADgCADABQAAACAHAAQAHAAAAgCQAHAAAEgDIAJgIQAHgBAEAAQACgEAEABQAGACACAAQAAgBASgGIAUgIQgDgDABgCQACgCAFAAQADADAFgCIAIgDQAAgBAHgBQAHgBAAgDIAGACQAIgFgEAAQgBgDAPgEQAQgEAAgCQAHAAAHgDIAOgIQABgCAIABQAHABAAgEIADgDQABgCAFAAQAEAAAHgDQAAgBAKgDQAKgCADABQgBgFAFgDQAGgEACgDQAPABAAgDIAHABQAEAAABgEIAKgIQAAgDAIgEQAHgFAEAAIALAAQAAABATgLQAAgDAHgFIAIgFQAGAAAIgHQAIgIAFAAQAAADASgNQAIgGAKAAQAUgNAAgCIAWgPQALAAAMgIQADgHAEAAQADgDAJgDQAJgEACgDQAFAAADgGQADgHADAAIAKgHQABgDAEgEIAHgGIAGgCQAFgBABgCQAAgFANgGQAMgHgBgDQAVgZADgBIAHgPQAFgKgHgDQAAgCgHgEQgIgDgBgDQAAgDgEgCIgHgFQgMgLgGgDIgQgHQgNgHAAgDQgGAAgJgFQgKgGgEgBQAAgBgJgFIgKgHQgEgBgIgFQgHgFgEAAQAAgBgSgEQgUgHgDgDIgQgIIgKABQgHABgEgBIgFgCIgHgBQgRgLgDAAQAAABgSgHIgJgDQgDgEgGgCIgKgBQgtgKgGgBQgGgHgWADQgSACgDgEQgDgEgHAAQAAgBgOACQgPACAAgDIgTgBQAAgEgGgBQgHgHgIAEIgNAFQgHAAgKgEIgRgGQAAAFgXgBQgWgBAAgJQABgEgFgBQgEgBgFABQgCADgIgCQgBgBgBAAQgBAAAAAAQgBAAAAABQAAAAAAAAQgBABAAAAQAAAAgBABQAAAAgBAAQAAABgBAAQAAADgJgBQADAHAAAEQAHAAACAeQACAcgCAIQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAABABQAAAAAAAAQgBABAAAAIgBAUQgBATgEAAQgBADADADIgIAQIgGANQgFAIAAAGIgGAPQgFAOgHAAIABAFQgBAAAAAAQAAABgBAAQAAAAgBAAQgBAAAAAAIAAAEQgCAAgCAGQgBAGgDAAIAAAEQAAABgBAAQAAAAAAABQAAAAgBABQgBAAAAABIgFAEIgBAHQgDAAgBAFQgBAAgGAIQgHAJgFABQgBADgIADQgIACABAFIgCAFIgCADQAAACgEAEIgGAFQAEAKgSACQgBAGgHAEQgIAGgCADQgFAIgTAJQgCABgDAEIgFAFQgJAAgRAOQgUARgFACIgNAFQgJAEAAAEIgLAHQgGAFgGABQAAgBgFAFQgFAEABAAIgKAFIgKAGQAAABgLADQgMADAAAEQgJAAgRANQgSAMgMAAIgKADQgIAEgBABIgJAHQgFAFgFAAQgeAKgEAAQAAACgJAGQgJAFAAgEQgEAAgHADQgHAEgDADIgLACQgFABgEAFQgFAAgKAGQgJAGgEAAQgDAFgVAAQgCADgDACQgEABgBACIgGABQgEABgCgCIgGgDQgHgBgGADIgKAIQgBAFgNAEQgDAAgIAFQgHAEgEAAQgsANgHAAQAAADgZAHQgaAIgDADQgTACghANQgHADgOAAQAAAGgPAAQAAACgVAGQABgGgiAKQgEAAgGACIgKAEQAAgBgMAEIgPAFQgIAGgMACIgWAFIAFAAIABABIARACQAOACABgDQAcAAASAEQAsgBAAAFQAFABAvgHQAHgDAHAEIANAHQAAgCAQgCIAUgCIAQgBQAEABACADgAqtGZQgHgMAAgBIAHAFIAGAEQAAAAAAAAQABABAAAAQABAAAAAAQABAAAAAAIADgBQgBgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAIgGAAIgCgBIgBAAIAAgBQgDgDgDgCQAAAAAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBIgDgBQgjAFAAgEIgJgBIgIgCQAAgEgOACIgQADQgGAJATADQAWADAAABIAVABQARAAAAACIASAAIAAAAgAopGGQgDABAAAFIADAEIAEAFIAHgBQALAAgJgLQgFgEgEAAgAmTFsIAIAOIAFAFIAOACQABAAAAAAQABAAAAAAQABAAAAAAQAAgBAAAAIAOgCQAJgCAEABIBCgLQAAgCAVgDIAYgEQBOgSAHAAQAAgBAXgGQAXgFAEAAQAAgDAWgEQAWgDACgEQAHAAAKgEQALgDAGgBQAGAAALgEIAQgFQACgDAdgHQAagGgBgHQAYgBAAgDQAJgBARgHQAAgBAJgCQAJgCAAgBQADAAADgCQABgBAAAAQABgBAAAAQABAAAAgBQAAAAAAgBIAGgBIAFABQAAgDAQgFQAOgEAFAAQACgDAJgDQAKgCAAgDQAEAAAIgDQAJgDACgDQAGAAALgEQAJgEAFgEQAGgFAPgDQABgCANgEQANgEAAgCIANgGIAOgHIAPgFQAKgEADgEQACAAAJgFQAIgEAAgBQAEAAAIgEQAIgFADgDQAKAAAOgKQAOgKAIgBQACgEAUgJQATgKgBgCQAAgBANgHQAOgHAAgBIAHgGQADgDAFgBQAKACAEgGIAEgIQAEgIAFAAQAAgBAFgEQAGgDAAgCQAFgBAIgHQAIgHAFgBQADAAACgFQACgFADgBIAIgFIALgKQAEgCAFgHQAFgHAEgCQAAgFAOgMIAOgRQACgEAFgIQAGgIACAAQABgGAFgHIAGgMQACAAACgFIACgGIACgHQACgGgBgDQgFAAgJAOQgKAQgEACQAAAGgMAJIgLAKQgGAHgEACQAAAFgHAFIgKAKQgBACgIAFQgHAEAAAEQgDABgDAEQgDAEgFABIgEAFQgEADgCAAIgHADIgIADQAAACgEADQgFAEgBADIgKAGQgHAGgBACQgDAAgJAGQgJAGgCADQgKADgQANQgPAMgMACQgFAGgMAEQgLAEgIAAIgOAOQgFAAgHAGQgHAFgDAAQgCAEgIABQgHABgDADIgHADIgGADQgCAAgEAEIgFADQgCAEgJAAQgJABgDAEQgEACgDAAQgCAEgIABIgNABIgJABQgGAAgDABQgDABgDAHQgDAGgEABQgEAEgFgCQgHgCgDABQAAAEgFACQAAAEgVAJIgbALQgDAAgFADQgFADgDAAQAAACgNACQgEAEgIADQgHACgGAAQAAACgNADQgNADAAADIgNACQgKACgCADQgGAAgCABQgDABgFAFQgHAAgGACIgNADIgWAHQgBACgKACQgKACAAACIgbAHQgFAAgIADQgIADgFAAQgCACgOAEQgNADAAABQgDAAgFADQgFADgDAAQgBACgGABQgFABgCgCQgRAHgCAAQgDADgNADIgMACQgEABgKAEQgIADgEAAQAAACgOAAIgQgCQAAABgJADIgMACQgPAAgMAFQAAAFgLACQgMABAAABIgXAAQgQAAgFAFIgDACIgDADIgJADIgHACQgCADgcAEQgcAFAAACIgFAAIgFAAgAxuEwQAAgCgHgCQgFgCgEAAQAAAGAQAAgAzoD+IgCADIAOALIAKACIALACQAEAHAcAKQAbAKAAgGQgOAAAAgHQgQgCAAgCIgUgKQgCAAgEgIQgEgHgGAAQAAgDgKgBIgKgBIAAAAIgGACgAmhD9QgJAEgBADQABAAAAAAQABAAAAAAQAAAAABAAQAAAAABAAIADAAQAAACAsgFIA0gGQAAgDAWgEIAcgFQABgDANAAIARAAQAFAAARgGQANgEAIACQAAgCATgDIAWgEQAAgFALACQAMACAAgEIAKAAQAGAAADgEIAJgDQAFgGAQACQAQABACgFQgIAAAHgEQAGgEAEAAIANgBIAEACIAFABIASgEQAAgCgFABIgHABQgDgGAcgHQAXgHAKAAQAAgBALgCQALgBABgCIAHgCIAHAAIADADIAFABQAAgBAAgBQgBgBABAAQAAgBAAAAQABAAABAAQgCgFAEgBIAJgCIAKAGQAKAGADgBIgHgDIgDgKIAGgFQADgBAFACQACABAMgFQALgFAAAEQADABAEgCQAEgCAAgCQAOAAADgFQAAgJAJAAQACgEAKAAIANAAQAFgBADgEQADgEADAAIAVAAIAEgJQADgDAEABIAGADQgBgJAGABIALADQADAAAEgDQAEgEADAAQACgCAJgFQALgFABACQAAgHAUgCQAUgCAAgCQAIAAAFgBIAFgDIAGgDQACgDALgDQAMgDAAAGQAEABAOgEQAGgEABgFQgEAAAEgHIAFgIQAEgCAAgJIANgHQAJgFAGAAQABACAKACIAMACQAAAEAMgGQALgFACgEQgHAAgCgMQAFAAAMgPQASgEAAgCQAMgCAOgGIAWgKQAFgFARgHQAOgGADgHQAGgCANgOQALgMAHAAQACgDAFgDQAFgEACgDQACgCAHgGQAHgFAAgEQACAAAFgIQAFgHAAgCQAEAAAJgXQAKgXgCgFQgCAAAAgMQABgMgEgCIADAAQgBAAgDgHIgHgRIgSgBQAAACgPgEQgPgDAAADQgmAHAAgBQgLABAAgCIgIABQgFABgDgDIgHABIgJABQAAgBAAAAQAAAAgBAAQgBAAAAAAQgBAAgBABIgGABQAAAEgMABQgLABgFgBIgPgBIgDAFQgBAAAAAAQAAAAgBgBQAAAAgBgBQAAgBAAgBIgOABQgCAHgNgEIgUgGQgBACgIABQgFABAAAHQgYAAgEABQAAADgUABQgUABAAACIgZABQgLAAgDADIgBABQAAABAAAAQAAAAgBAAQAAABgBAAQAAAAgBAAIgQABQAAABgGACIgIABQAAgBgSADQgTACAAACIgMADQgIACgFAAIgJAIQAAAEgJgHQgDAAgBADIgCAFQgBADgEABIgGABQAAAEgMAAQgBACgEABQgEABgDADQgDADgGAAQAAgEgGABIgKACQAAAFgWgCQAAAGgJADQgLADgCACQgCAAgEADIgHAEQgEACgCgBQAAgBgBAAQAAAAgBAAQgBAAAAAAQgBAAAAAAQgDAAgCgCQgEgCgCAAIgIADIgIACQgDgCgEACIgHADIgEAEQgEAEAAACQgBAAAAAAQAAABAAAAQgBAAAAABQAAAAAAABIgBAEIgEAFIgCAAQAAAAAAAAQgBAAAAABQAAAAAAAAQgBAAAAAAQgDABgCgCQgDgCgCABQgFAJgVACIgUAMQgKAEgEgDIAAgEQAAgBgBAAQAAgBAAAAQgBAAAAAAQgBAAgBAAQAAgBgKAHQAAAHgEABIgIgCQgBgBgHADQgHADgBACQgFAAgDADQgDADABAEIgMACQgNADgEAFQgEAAgBAFIAAAGIgRAJQgEAGgIAAIgMgCQACAMgGACIgMAHQgMAIAAgFQgGgEgBADIAAAEQAAADgKAIQgLAGgEABQAAACgGAEIgKADQAAgGgFAEQgHAFACAAQAAAFgHAIQgGAHgFAEQgCAFgFADIgKAEQgJADgDgEIgIAHQgFAFAGAAIgCAHIgGAJQgFAGgCAAIgKAJQgHAHgCAEQgGAAgCADIgEAJQgEABgEAFIgGAHQACAEgZAYQgBAAAAAAQgBABAAAAQgBAAAAABQgBAAAAABIAPgBIAqgFQAAAFARgHIAFAAIADgCQAAAAABAAQABgBAAAAQAAAAABAAQAAAAAAABIAEACQABgFAKgDIAJgEQAGAAAVgEQASgDAEAIQAAgBABAAQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAgBQgBAAAAAAQAAAAAAgBQAAgBABAAQACgEACAAQAAgBAFABIAHAAQAAgBAGAAIAJgBQAAABAAAAQAAABABAAQAAAAABAAQABAAABAAQAAgKAqAAQAAgEAKgBIAOgBQAAgHAZgBQAZgCAAADQADgBAEgEQAEgDACAAQAAgCAHACIAIACQAAAHAVgMQAAgCAHgDIAJgCQAFAHAHgBIARgDIAOgBQAHgBAAgGQgEADgEAAQAAgEADgCQAEgCABgCIAOgCIAGgCQAAgFALAAIAPAAQAHAHAGgGQAJgKAEgBQAMAAAAgCQAFAAADAFQACAFgHAAQAAAEAHACQAGADAAgFQgEAAgBgDQAAgEAEAAQAAgCAKAAIAGgEQAFgCAAgDQAHAAAEgDQABgCAEABQAEABACgBQAEgHALAAQACABAHgDIAIgEQAVgLAAAFQALAAgDgBQgIgEgBgCQgHgCAGgCIAJgBIAFAGQACACAEABQAMAAAAgCIAYgLQAFAAAJgEQALgEAFAAQAAgEAMgEQAKgDAFAAQABgCAFgCQAFgCACgCQAQgEACAAQAEABADgDQAFgFADgBIAJgFQAHgDACAEQACADgLANQgEAAgHAGQgIAFgEAAQAAAFgNAGQgOAGgCAEQgCAEgKACQgIABgCAEQgEAAgHAFIgJAHQgcALAAgBIgTAPIgMAEIgLAEQgZAGgGAIQgGgBgGAEQgGADgEAAQAAABgMABQgLABAAAGIgQADQgLACgEAEQgMAGgHABQAAACgJADIgKAEIgEAAQgBAAgBAAQAAAAgBAAQAAAAAAgBQAAAAAAAAIgKADQgEAGgJABIABADIgGACIgHACIgJAAQgFgBgEABIgKAGQgKAFAAgBQgIAAgPAFQgPAFgJAAQAAABgWAEQgWAEAAADQgdALAAgEQgEAAgIAFQgHAFgEAAIgQAFQgRAEgBABIgZAFIgkAJQgaAAgCAEIgIACIgIACQAAgDgUAHIgNAEQgIADgHAAQgKADgFAAIgTAAQgFAFgMAAQgNgCgFABQAAABgIACIgLADIgBgBIgIACgAz3D2QAEgHgIgCQAAgBgEgEIgFgFQgDAAgIgFQgHgEgEAAQgBgDgHgGQgHgGgDAAQAAgCgLgIQgLgIgEAAQACAFAGAIQAGAHAFADQANAKgCAAQADAFAGAAQAWATAAgCQACABAFgCQAAAHALAAgApzCuIAGAEQgEABgCADQgDAEADADQAFADgDADIgEAEQATgEAAgBQADgBAFABIAHACIAEgBIADgDIADgBIAKgCQgFgZACAAIgCgJQgCgGABgDIACgOQABgIABgEQADAAgBgIQgBgIgGgBIgMASQAAAFgGAJQgGAJABAEQgGADgCACIgEAJQgCAAgCAEIgDAFQAAAEgIgGQgBABAGAEgAnqBaQgEAAgDAIQgEAKgDABQgDAVgBAAIAAACQgDAAgDAUQgDAUACADQADgBAFgIIADgIQADgHACAAIAFgLQAEgIACAAIADgHQAEgFAAgDQACAAAEgJIAFgLIAIgGQAHgGAAgCQAEAAABgDIABgIQACAAACgDQABgEADAAQAIgJABgEQAAAAABAAQAAAAABAAQAAgBABAAQAAAAAAgBIACgFQAIgFAHgLQAEAAAGgJQAFgJAGAAQAegLgOAAQAAgGAFgCIAJgDQAAgGAIgEQAIgEAAgFQAFgBADgEQAEgFADgBQACgDAMgGQALgFAAgEQAKgGAGAAQAAgEAIgFQAIgEAAgDIAGgEIAHgEIAHgFQADAAAIgHQAIgGABABIALgGQAIgFACgDQAHgFABgGQAFAAAGgBQAGgCAJgGQAAAHAMgIIAPgKQACAAAGgEIAHgGQABgBAIgDIAIgDQAhgKAAgDQAFAAAJgEQAIgDAGAAQABgEAFACQAHABACgIIAGgCQACAAAHgEQACgCAOgEQANgDAAgCIAJgDQAGgDAAgDQAQgCAAgBIAJgCQAHgCAAgBQAFAAAKgEQALgFAGgBQAAgBAIgDIALgCQA2gRAEAAQAAgBAOgDIAQgEQATABAAgGQAFAAALgDQAKgDAGAAIAfgIQAAgCAMgBIAOgBQAAgCAMgCQAMgBABgCQAEAAAGgCQAHgDAEAAIAMABQAHgBADgDQAXgCAKgDQAAgEAygEQADgFAeAAQASABARgEQAAgFA4gBIA+gBQAAgCAGABQABAAABAAQABAAAAgBQABAAAAgBQAAAAAAgBIADAAIgBgCQgEAAgEgIQgFgIgDAAQAAgDgHgHQgHgGAAgEQAHgCAJADQALADAAAIQAEABAFAEQAFAEACAEQADACAAAFIADABQAAAAAAAAQABAAAAABQAAAAABAAQAAABAAAAIAEADQAEgBAEABQAGABAMgBIAUAAIAmACQAhABAAABQAIABAHgBQAAgCAUACIAZADQArACAAACIAzAEQArAFAAAGQAKAAAUAFQAVAEAKAAQAAACAPADQAPACAAACQAHABAKAEQAJADAHABQADABAHADQAGADADAAQAAADAJAAQAKABABACIAcAJQAEAAAIAEQAJAEACADQAOAHAAgDIAEABIACACQAEAAALAGQALAGAAABQAFAAAIAGQAIAFAEAAQAAABAHAFQAHAEACAAQAAABAIADQAIAEABACQADADAKAFQAIAFADAEQAHAAgHgJQgGgKgFAAIgEgEQgEgDAAgCQgIAAgHgKQgEAAgKgJQgLgKAAgDIgLgBQgHgCAAgEIgDgCIgGgBQgIgIgCgBIgOgHQgGgEgHAAQgEgFgKgDQgEgBgBgCQgCgDgCgBQAAgCgSAAQAAgGgLgCIgPgCQgHAAgHgDQgIgEAAgEQgIAAgNgJQgNgKgHAAQAAgBgKgCIgKgBQgZgHAAgCIgPgDQgIgDgEAAQAAgEgdgGQgZgEgKAAQAAgCgOAAQgPgBAAgEIgXgDQAAgDgbgCIgbgDQgZgDgMAAQAAgBgMgBQgMgBgBgBIgbgBQAAADgogCQgBgCgOAAQgNgBAAACQgDABgGgBIgIgBQgRACgIgBIgKADQAAABgKAAIgMgBQAAADgVACQgVABgFgBIgwAEIg5AEQgFAAgYAEQgZAEAAACIgXACIgUADQAAAHgyACQAAADgkAGQgCADgJAAQgJAAgDAEQgFgBgGACIgJABQAAACgOABQgNABAAADIgeAJQgSAFgLAAIgdAKQgeAJgCgBQAAAEgNACQgOACgBAEIgOAEQgIACgFABQAAABgHADIgIACQAAABgKAEIgPADQgCAEgLADQgLADgCAEQgEAAgGADQgHAEgDAAQgVAFgFAHQgFAAgIAGQgJAGgFAAQgDADgHAEQgHAEgEAAQgCADgPAIQgEAAgJAHQgIAHgHgCQgBAEgJAAQgBAEgIADQgNAFgHAGIgPAJIgPAJIgJAIQgEAFgFAAQABgCgKAHQAAAGgYAPQgLAMgKAEQAAABgEADIgGAEQAAAAgBAAQAAAAgBAAQAAABAAAAQgBAAAAABQAAABgFAAQgBgBAAAAQAAAAgBgBQAAAAgBAAQAAAAgBAAIgEABQgDAEgMAHIgDAEIgEAEQAAADgEAEQgDAEgDAAIgFAHIgHAFQAAACgJAIQgDADgEACQgFABgDADQAAADgEACQAAADgDACIgGAEQgCACAAAEQAAAFgCACIgFADQgDAAgCADQgCAFgBAAQgBACgEAGQgEAFgCABQAAAGgJAGQgKAGAAAGQABAAgFARIABAIQgBAFgDABIgBABIAAAAIgBABgAxpmXQgDABgCACIgCAFQgHAAgCADQgCAAgGADQgFADgCACIgHADIgGADQgGAHgTAGQgCAEgKACQgKABgBADIgHAGQgGAFAAABQgOAAgBAHIgSAOQgEAAgPAKQgJAGgGAHQgCADgFADQgFADgCADQAAAHgIAEQgKAEgBAFQgCABgDAGQgCAEgDABQgBACgGAFQgFAEAAADIgJAJIgIALIgDACQACACAlgbQAmgdAHgBIAHgFQAEgDADAAQAAgBAEgCIADgEQgDgBAAgEIAMgBQAIgCACgCIADgCQAAgBABAAQAAgBABAAQAAgBAAAAQABAAAAAAQABgCAGgDQAFgDACAAQACgDALgFQAJgEACgDQADAAAFgFIAHgHQAMgEABgBQADAAAHgEQAJgEADgBQACgCAHAAQAEABABgFQABgJANAAIAHgIQACgDAFABQAFABABgDQACAAAHgEQAHgFACgBQAAgCARgHQAQgHADABIgBgEQAGgBAHgEQAHgEAFgBIALgFQAHgEACgDQADAAAFgCIAHgDQACgCAFAAIAIABQACgFADgCQAGgHAPgDIAYgDQACgDAIgDQAIgDAEAAQAAgDAIACQACABAEgCIAGgEIAIgEQAEgCADAAQAEgGAOgEIAWgEQAGgBALgDQAOgEAAgDIAHgCIAFgDIAJABQAFgBAAgFQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAAAABgBIACgDIgGgDIgvAMIgCgBQAAACgLABQgKACAAABQgHAAgLAGQgLAGgGABIAAgDQgFAAgKADQgJADgFAAQgEgBgCADIgFAEQgEAEgCAAIgHgDIgIAEQgIADgBAEIADABQgBADgFAAQgEABACgEQgDAAgHADQgHADgEAAIgFACQgGADgBACIgDAFQgDABgDgBQgCAGgOAFQAAABgFABQgFAAAAABIgLACQgEABgCAHIgDABQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAAAAAgBQgKAAAAgCQgCAAgDACQgEADgCABIgOAHQgNAIACABIgNAGIgNgCIgDABgAlSlJQgFgDAKgGIALgHQAIgDAAgBQABgBABAAQAAAAABAAQABAAAAAAQAAABABABQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAAAQACACgOAJQgJAGgFAAIgEgBg");
	this.shape_1.setTransform(7.7928,27.7457,0.4948,0.4948);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("ABwDnIAAkXQAAgygageQgbgeguAAQgfAAgdAPQgdAPgkAjIAAFEIhjAAIAAnEIBjAAIAAA8IADAAQAdghAogSQAngSAqAAQBLAAAvAtQAxAxAABZIAAEWg");
	this.shape_2.setTransform(117.997,94.1892,0.4949,0.4949);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjCCoQhLhEAAhnQAAhiBNhCQBNhDBxgBQB2AABNBCQBNBBAABlQAABqhMBCQhMBDh4AAQh1AAhLhEgAh4hvQgvAqAABCQAABGAuAsQAtArBIABQBPgBAugqQAugrAAhIQAAhBgwgrQgxgrhKAAQhGAAguArg");
	this.shape_3.setTransform(90.4194,94.4243,0.4949,0.4949);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AiqEwQhCgnAAg8QABgyAegeQAfgfBBgOQgygbAAgeQAAgWAWgRQAWgRAjgIIAAgCQg3gVgdgkQgbgjAAgyQAAhIA8gqQA7gqBkAAIDRAAIAABFIhoAAQAeAbAMAWQALAVAAAdQAAAbgPAeQgNAcgTARQgiAghdAPQgoAGgOAGQgXAJAAARQAAASAnAOQAiAMBQAOQBNAOAlAjQAhAfgBAuQAABEg/AmQg/AmhvAAQhmAAhBgmgAhtCYQggATAAAeQAAAiAkASQAkASBEAAQBBAAAlgRQAlgSAAgfQgBgmg7gUQgsgOg9AAQgyAAggATgAhIjvQgdAYAAAhQABAlAbAXQAcAXAtAAQApAAAcgYQAbgYAAglQAAgggdgYQgdgYgnAAQgpAAgeAZg");
	this.shape_4.setTransform(64.4501,100.1526,0.4949,0.4949);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AijCiQhAhEAAhiQAAhoBCg/QBChABoAAQBmAAA5A+QA8BAAAB7IliAAQAYCHCQAAQBVAABbg2IAABXQguAcgsAMQgxAOg9AAQhxgBhEhJgAhPiAQgjAdgKA2ID9AAQgDg0gfgeQgggeg0AAQg4AAgiAdg");
	this.shape_5.setTransform(39.7057,94.4243,0.4949,0.4949);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ai3DnIAAnEIBkAAIAABoIACAAQBHhxBKAAQA6AAA/A1Ig1BNQgXgTgbgNQgagMgSAAQgzAAgjAoQgjApAAA6IAADsg");
	this.shape_6.setTransform(19.9101,94.1892,0.4949,0.4949);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("Aj1DJQhahSAAh3QAAh3BchTQBfhVCUAAQCWAABfBVQBbBSAAB4QAAB3haBSQhfBXiYAAQiVAAhfhXgAitiYQhGA8AABcQAABcBGA9QBFA9BoAAQBpAABFg9QBFg8AAhdQAAhchFg8QhFg9hpAAQhoAAhFA9g");
	this.shape_7.setTransform(-9.6965,91.7272,0.4949,0.4949);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AijCiQhAhEAAhiQAAhoBCg/QBChABnAAQBnAAA5A+QA8BAAAB7IljAAQAMBCArAjQAqAiBIAAQBUAABdg2IAABXQgwAcgrAMQgwAOg/AAQhvgBhFhJgAhQiAQgjAdgKA2ID+AAQgDg0gfgeQgggeg0AAQg4AAgjAdg");
	this.shape_8.setTransform(-41.7282,94.4243,0.4949,0.4949);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ai4DnIAAnEIBkAAIAABoIADAAQBHhxBKAAQA7AAA9A1Ig1BNQgWgTgbgNQgagMgSAAQgyAAgkAoQgkApAAA6IAADsg");
	this.shape_9.setTransform(-61.1773,94.1892,0.4949,0.4949);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("ABFDgQgTgLgHgYQhAAuhHABQg2AAgkgiQgiggAAguQABg7A3gkQAfgUBVgbIBYgcIAAgYQAAgpgWgUQgWgTguAAQhZAAhHBLIAAhiQA7g+BtAAQBQABAxAjQA1AoAABKIAADoQAAAXATAAQARAAAkgYIAAA2QgjAVgTAHQgUAIgWAAQghAAgSgMgAhCAtQgxAbAAAkQABAcAUASQAVASAeAAQAsAAArgmIAAiDQhOAXggATg");
	this.shape_10.setTransform(-84.536,94.4243,0.4949,0.4949);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AjIDAQhRhQAAhnQAAiABhhUQBhhUCUAAQBcAAB7AuIAABXQg6gfg0gOQgzgOg3AAQhqAAhHA9QhHA+AABbQAABeBGA8QBGA7BwAAQBsAABug/IAABXQgzAYgwAMQg6AOhFAAQihAAhfhgg");
	this.shape_11.setTransform(-112.7818,91.9993,0.4949,0.4949);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CO_v_white, new cjs.Rectangle(-126.7,-7.3,264.2,124.39999999999999), null);


(lib.BUTTON = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// type
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAqIAlgqIglgpIAaAAIAmApIgmAqgAg2AqIAmgqIgmgpIAcAAIAlApIglAqg");
	this.shape.setTransform(34.775,5.075);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5BQIAAicIAeAAIAAAOQAOgRAUAAQAXAAAOAPQAOARAAAcQAAAbgOAQQgOAQgXAAQgUAAgOgSIAAA6gAgQgxQgHAEgEAFIAAAoQAEAFAHAEQAHAEAIAAQAMAAAHgJQAJgJgBgOQABgPgJgJQgHgKgMAAQgIAAgHAEg");
	this.shape_1.setTransform(19.4,7.125);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgOBPIAAidIAdAAIAACdg");
	this.shape_2.setTransform(9.75,2.925);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgoArQgRgQAAgbQAAgYAQgSQARgRAZAAQAaAAAPARQAQASAAAaIAAAHIhUAAQACAMAIAGQAJAJANgBQATAAALgLIAOAUQgRAQgeAAQgaAAgRgRgAAdgKQgBgKgGgHQgIgHgNgBQgMABgIAHQgGAHgBAKIA3AAIAAAAg");
	this.shape_3.setTransform(0.925,5.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAXBPIAAhGQAAgUgUAAQgQAAgJANIAABNIgfAAIAAidIAfAAIAAA6QAOgRAYAAQAlAAAAAkIAABQg");
	this.shape_4.setTransform(-11.8,2.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgqBAQgPgQAAgcQAAgaAPgRQAOgQAWAAQAUAAAOASIAAg6IAeAAIAACcIgeAAIAAgOQgOARgUAAQgWAAgOgQgAgSgDQgIAIAAAPQAAAPAIAJQAIAJAMAAQAHAAAIgDQAHgEAEgGIAAgoQgEgFgHgDQgIgEgHAAQgMAAgIAJg");
	this.shape_5.setTransform(-30.6,3.075);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AAXA7IAAhFQAAgVgUAAQgPAAgKANIAABNIgfAAIAAhyIAfAAIAAAPQAOgSAYAAQAlAAAAAlIAABQg");
	this.shape_6.setTransform(-43.3,4.95);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOBRIAAhxIAdAAIAABxgAgLgxQgGgGAAgIQAAgHAGgFQAEgFAHAAQAHAAAGAFQAFAFAAAHQAAAIgFAGQgGAEgHAAQgHAAgEgEg");
	this.shape_7.setTransform(-52.5,2.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag3BPIAAidIBvAAIAAAeIhNAAIAAAhIBLAAIAAAcIhLAAIAABCg");
	this.shape_8.setTransform(-61.175,2.925);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// bkgd
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#00A7B5").s().p("Aq0C4IAAluITwAAIB6CtIh6DBg");
	this.shape_9.setTransform(-10.4,3.85);

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

	// shad
	this.instance = new lib.Buttonshad();
	this.instance.setTransform(-80,-15,0.6438,0.6438);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BUTTON, new cjs.Rectangle(-96.8,-15,166.2,56), null);


(lib.BKGDblue = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#256BA2").s().p("A3ZKVIAA0pMAuzAAAIAAUpg");
	this.shape.setTransform(0,66.1);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BKGDblue, new cjs.Rectangle(-149.7,0,299.5,132.2), null);


(lib.BKGD = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FF8300").s().p("A96WbMAAAgs1MA71AAAMAAAAs1g");
	this.shape.setTransform(0.0067,125.0449,0.7833,0.8714);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.BKGD, new cjs.Rectangle(-150,0,300,250.1), null);


(lib.HEAD3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.HEAD3type();
	this.instance.setTransform(0,24,1,1,0,0,0,0,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD3, new cjs.Rectangle(-139,0,262.1,47.7), null);


(lib.HEAD2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.HEAD2type();
	this.instance.setTransform(0,36,1,1,0,0,0,0,36);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD2, new cjs.Rectangle(-139,0,278,36.3), null);


(lib.HEAD1b = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.HEAD1btype();
	this.instance.setTransform(0,24,1,1,0,0,0,0,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1b, new cjs.Rectangle(-139,0,278,47.7), null);


(lib.HEAD1a = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.HEAD1atype();
	this.instance.setTransform(0,24,1,1,0,0,0,0,24);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.HEAD1a, new cjs.Rectangle(-139,0,278,47.7), null);


// stage content:
(lib.CO_MhSubstance_320x50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0,359];
	// timeline functions:
	this.frame_0 = function() {
		//if(!this.alreadyyExecuted){
		//this.alreadyyExecuted=true;
		//	this.clickthru_btn.on("click", function(evt){
		//  window.open(clickTag, "_blank");
		//});
		//} else {
		//gotoAndPlay(2);
		//}
	}
	this.frame_359 = function() {
		//if(!this.alreadyExecuted){
		//this.alreadyExecuted=true;
		//this.loopNum=1;
		//} else {
		//this.loopNum++;
		//if(this.loopNum==2){
		this.stop();
		//}
		//}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(359).call(this.frame_359).wait(1));

	// border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,2,0,3).p("A46j0MAx1AAAIAAHpMgx1AAAg");
	this.shape.setTransform(160,25);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(360));

	// HS logo
	this.instance = new lib.HS_logowhite();
	this.instance.setTransform(154.9,25.1,0.28,0.28,0,0,0,0.7,71.8);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(323).to({_off:false},0).wait(37));

	// CO logo
	this.instance_1 = new lib.CO_v_white();
	this.instance_1.setTransform(250.2,25.25,0.33,0.33,0,0,0,0.3,55.6);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(323).to({_off:false},0).wait(37));

	// mask (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_323 = new cjs.Graphics().p("A4/D6IAAnzMAx/AAAIAAHzg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(323).to({graphics:mask_graphics_323,x:160.004,y:24.9987}).wait(37));

	// CTA
	this.instance_2 = new lib.BUTTON();
	this.instance_2.setTransform(-27.3,25.1,0.76,0.76,0,0,0,-10.4,3.9);
	this.instance_2._off = true;

	var maskedShapeInstanceList = [this.instance_2];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(344).to({_off:false},0).to({x:52.7},15,cjs.Ease.quadOut).wait(1));

	// BKGD-orange
	this.instance_3 = new lib.BKGD();
	this.instance_3.setTransform(160.1,43.35,1.0667,0.1999,0,0,0,0.1,216.8);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(323).to({_off:false},0).wait(37));

	// HEAD1a
	this.instance_4 = new lib.HEAD1a();
	this.instance_4.setTransform(164,24,1,1,0,0,0,0,24);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(107).to({alpha:0},8,cjs.Ease.quadInOut).to({_off:true},1).wait(244));

	// HEAD1b
	this.instance_5 = new lib.HEAD1b();
	this.instance_5.setTransform(164,24,1,1,0,0,0,0,24);
	this.instance_5.alpha = 0;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(43).to({_off:false},0).to({alpha:1},6).wait(58).to({alpha:0},8,cjs.Ease.quadInOut).to({_off:true},1).wait(244));

	// HEAD2
	this.instance_6 = new lib.HEAD2();
	this.instance_6.setTransform(164,36,1,1,0,0,0,0,36);
	this.instance_6.alpha = 0;
	this.instance_6.shadow = new cjs.Shadow("rgba(0,163,181,1)",0,0,0);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(116).to({_off:false},0).to({alpha:1},8).wait(77).to({alpha:0},8).to({_off:true},1).wait(150));

	// HEAD3
	this.instance_7 = new lib.HEAD3();
	this.instance_7.setTransform(164,24,1,1,0,0,0,0,24);
	this.instance_7.alpha = 0;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(210).to({_off:false},0).to({alpha:1},8).wait(142));

	// BKGD-blue
	this.instance_8 = new lib.BKGDblue();
	this.instance_8.setTransform(160,25,1.0684,0.6808,0,0,0,0,66.1);
	this.instance_8.alpha = 0.6992;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(360));

	// PIC
	this.instance_9 = new lib.MhSubstance_728x90();
	this.instance_9.setTransform(1,0,0.3754,0.3754);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(360));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(159.5,5,388.1,65);
// library properties:
lib.properties = {
	id: '0957C5EC3B874C629166840920B09671',
	width: 320,
	height: 50,
	fps: 36,
	color: "#999999",
	opacity: 1.00,
	manifest: [
		{src:"images/CO_MhSubstance_320x50_atlas_P_1.png?1616959664616", id:"CO_MhSubstance_320x50_atlas_P_1"},
		{src:"images/CO_MhSubstance_320x50_atlas_NP_1.jpg?1616959664616", id:"CO_MhSubstance_320x50_atlas_NP_1"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['0957C5EC3B874C629166840920B09671'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;